// @orca-managed-pi-extension
function processName(value: unknown): string {
  return String(value || '').split(/[\\/]/).pop()?.toLowerCase() || ''
}

const CONFIGURED_HOOK_PATH = '/hook/pi'
let cachedOmpRuntime: boolean | null = null

function isOmpRuntime(): boolean {
  if (cachedOmpRuntime !== null) return cachedOmpRuntime
  if (CONFIGURED_HOOK_PATH === '/hook/omp') {
    cachedOmpRuntime = true
    return true
  }
  const executableNames = [
    processName(process.title),
    processName(process.env._),
    processName(process.argv[1]),
    processName(process.argv[0])
  ]
  cachedOmpRuntime = executableNames.some((name) =>
    ['omp', 'omp.js', 'omp.sh', 'omp.cmd', 'omp.exe', 'omp.bat'].includes(name)
  )
  return cachedOmpRuntime
}

const BRAILLE_FRAMES = [
  '\u280b',
  '\u2819',
  '\u2839',
  '\u2838',
  '\u283c',
  '\u2834',
  '\u2826',
  '\u2827',
  '\u2807',
  '\u280f'
]

const FRAME_INTERVAL_MS = 80
// Pi rewrites titles without observable events; reassert markers even without spinner frames.
const MARKER_REASSERT_MS = 1000
const AGENT_END_IDLE_RECHECK_MS = 25
const AGENT_END_IDLE_RECHECK_MAX_MS = 250
// Failed idle compaction may never send end; cap its spinner without relying on an agent turn.
const IDLE_COMPACTION_MAX_FRAMES = Math.ceil(300000 / FRAME_INTERVAL_MS)

// The ! marker reports needs-input to mobile/CLI; - is only a separator.
function getMarkedTitle(pi, marker) {
  const cwd = process.cwd().split(/[\\/]/).filter(Boolean).at(-1) || process.cwd()
  const session = pi.getSessionName()
  return session
    ? `\u03c0 ${marker} ${session} - ${cwd}`
    : `\u03c0 ${marker} ${cwd}`
}

function getBaseTitle(pi) {
  return getMarkedTitle(pi, '-')
}

// ctx.ui getters throw after session replacement; optional chaining cannot replace this guarded read.
function resolvePainter(ctx) {
  try {
    return typeof ctx?.ui?.setTitle === 'function' ? ctx : null
  } catch {
    return null
  }
}

export default function (pi) {
  if (!process.env.ORCA_PANE_KEY) return
  // Child processes inherit pane identity; only the owner may report the pane's needs-input marker.
  const markerOwnerPid = process.env.ORCA_PI_TITLE_MARKER_OWNED
  const ownsMarker = !markerOwnerPid || markerOwnerPid === String(process.pid)
  if (ownsMarker) process.env.ORCA_PI_TITLE_MARKER_OWNED = String(process.pid)
  // Factories share the process realm; retire old ownership before painting.
  const ownersKey = Symbol.for('orca.pi.titlebar.owners')
  const owners = globalThis[ownersKey] ??= new Map()
  const paneKey = process.env.ORCA_PANE_KEY
  let disposed = false
  function clearOwnedTimers() {
    clearPendingAgentEndCheck()
    clearAnimation()
    stopMarkerReassert()
  }

  function dispose() {
    disposed = true
    clearOwnedTimers()
    resetPromptState()
    if (owners.get(paneKey) === dispose) owners.delete(paneKey)
  }
  if (!owners.has(paneKey)) owners.set(paneKey, dispose)

  // Pi subagents start in-process with reason startup; only lead replacements (reload/new/resume/fork) take over.
  function claimTitle(event) {
    const owner = owners.get(paneKey)
    if (owner === dispose) return
    if (owner && event?.reason === 'startup') {
      disposed = true
      return
    }
    owner?.()
    owners.set(paneKey, dispose)
  }

  function on(name, handler) {
    pi.on(name, (event, ctx) => {
      if (name === 'session_start' && !disposed) claimTitle(event)
      if (!disposed) return handler(event, ctx)
    })
  }

  let timer = null
  let frameIndex = 0
  // Only idle maintenance owns a separate spinner; late compaction completion cannot stop a newer turn (#16470).
  let idleCompactionOwnsSpinner = false
  // A new turn proves no dialog holds input; recover when its close never arrived.
  let promptDepth = 0
  let markerPainted = false
  let promptCtx = null
  // Keep marker timers separate so turn settlement and idle-spinner caps cannot clear active dialog state.
  let markerTimer = null
  let pendingAgentEndCheck = null
  let pendingAgentEndContext = null
  let agentEndIdleRecheckMs = AGENT_END_IDLE_RECHECK_MS

// Both stale getSessionName and deleted-worktree cwd can throw; timer callback escapes would terminate Pi.
  function paintTitle(ctx, buildTitle) {
    if (disposed || !ctx) return false
    try {
      ctx.ui.setTitle(buildTitle())
      return true
    } catch {
      clearOwnedTimers()
      return false
    }
  }

  function resetPromptState() {
    stopMarkerReassert()
    promptDepth = 0
    markerPainted = false
    promptCtx = null
  }

  function clearPendingAgentEndCheck() {
    if (pendingAgentEndCheck !== null) clearTimeout(pendingAgentEndCheck)
    pendingAgentEndCheck = null
    pendingAgentEndContext = null
  }

  function stopMarkerReassert() {
    if (markerTimer) clearInterval(markerTimer)
    markerTimer = null
  }

  function startMarkerReassert(ctx) {
    stopMarkerReassert()
    markerTimer = setInterval(() => paintTitle(ctx, () => getMarkedTitle(pi, '!')), MARKER_REASSERT_MS)
    if (typeof markerTimer.unref === 'function') markerTimer.unref()
  }

  function clearAnimation() {
    if (timer) {
      clearInterval(timer)
      timer = null
    }
    frameIndex = 0
    idleCompactionOwnsSpinner = false
  }

  function stopAnimation(ctx) {
    clearPendingAgentEndCheck()
    clearAnimation()
    // Settling a turn cannot retire an unanswered dialog marker.
    paintTitle(ctx, () => (markerPainted ? getMarkedTitle(pi, '!') : getBaseTitle(pi)))
  }

  function renderFrame(ctx) {
    // Apply the maintenance cap before dialog guards so open dialogs cannot suspend it.
    if (idleCompactionOwnsSpinner && frameIndex >= IDLE_COMPACTION_MAX_FRAMES) {
      stopAnimation(ctx)
      return
    }
    // Reassert dialog markers against Pi's independent title writes while still accruing frames toward the maintenance cap.
    if (markerPainted) {
      const painted = paintTitle(ctx, () => getMarkedTitle(pi, '!'))
      frameIndex++
      return painted
    }
      const painted = paintTitle(ctx, () => {
        const frame = BRAILLE_FRAMES[frameIndex % BRAILLE_FRAMES.length]
        const cwd = process.cwd().split(/[\\/]/).filter(Boolean).at(-1) || process.cwd()
        const session = pi.getSessionName()
        return session ? `${frame} \u03c0 - ${session} - ${cwd}` : `${frame} \u03c0 - ${cwd}`
      })
      frameIndex++
      return painted
  }

  function startAnimation(ctx) {
    clearPendingAgentEndCheck()
    clearAnimation()
    if (!renderFrame(ctx)) return
    timer = setInterval(() => renderFrame(ctx), FRAME_INTERVAL_MS)
  }

  function checkPendingAgentEnd() {
    pendingAgentEndCheck = null
    const ctx = pendingAgentEndContext
    if (!ctx) return
    try {
      if (ctx.isIdle()) {
        pendingAgentEndContext = null
        stopAnimation(ctx)
        return
      }
    } catch {
      clearOwnedTimers()
      return
    }
    pendingAgentEndCheck = setTimeout(checkPendingAgentEnd, agentEndIdleRecheckMs)
    if (typeof pendingAgentEndCheck.unref === 'function') pendingAgentEndCheck.unref()
    agentEndIdleRecheckMs = Math.min(agentEndIdleRecheckMs * 2, AGENT_END_IDLE_RECHECK_MAX_MS)
  }

  on('agent_start', async (_event, ctx) => {
    resetPromptState()
    startAnimation(ctx)
  })

  // Reset/reload hides dialogs without resolving promises; both session boundaries clear the missing close.
  on('session_start', async (_event, ctx) => {
    clearOwnedTimers()
    resetPromptState()
    if (!isOmpRuntime()) paintTitle(resolvePainter(ctx), () => getBaseTitle(pi))
  })

  // Modern Pi can emit agent_end mid-run; prefer agent_settled while retaining the legacy fallback.
  on('agent_settled', async (_event, ctx) => {
    stopAnimation(ctx)
  })

  on('agent_end', async (event, ctx) => {
    if (event?.willContinue === true) {
      clearPendingAgentEndCheck()
      return
    }
    if (isOmpRuntime() || !ctx || typeof ctx.isIdle !== 'function') {
      stopAnimation(ctx)
      return
    }
    clearPendingAgentEndCheck()
    agentEndIdleRecheckMs = AGENT_END_IDLE_RECHECK_MS
    pendingAgentEndContext = ctx
    pendingAgentEndCheck = setTimeout(checkPendingAgentEnd, 0)
    if (typeof pendingAgentEndCheck.unref === 'function') pendingAgentEndCheck.unref()
  })

  on('ui_prompt_start', async (_event, ctx) => {
    if (isOmpRuntime() || !ownsMarker) return
    promptDepth++
    // Retry every open; an outer dialog's invalid context cannot suppress the whole stack.
    if (markerPainted) return
    const painter = resolvePainter(ctx)
    // Suppress spinner frames only after painting the marker, or the working title would freeze.
    if (!paintTitle(painter, () => getMarkedTitle(pi, '!'))) return
    markerPainted = true
    promptCtx = painter
    startMarkerReassert(painter)
  })

  on('ui_prompt_end', async (_event, ctx) => {
    if (isOmpRuntime() || !ownsMarker || promptDepth === 0) return
    promptDepth--
    if (promptDepth > 0) return
    // Reuse the opening painter if close arrives with a stale context.
    const painter = resolvePainter(ctx) ?? promptCtx
    markerPainted = false
    promptCtx = null
    stopMarkerReassert()
    if (timer) {
      renderFrame(painter)
      return
    }
    paintTitle(painter, () => getBaseTitle(pi))
  })

  on('auto_compaction_start', async (event, ctx) => {
    if (event?.reason !== 'idle') return
    // Idle compaction can race a new turn; never take ownership of its live spinner (#16470).
    if (timer && !idleCompactionOwnsSpinner) return
    startAnimation(ctx)
    idleCompactionOwnsSpinner = true
  })

  on('auto_compaction_end', async (_event, ctx) => {
    if (!idleCompactionOwnsSpinner) return
    stopAnimation(ctx)
  })

  on('session_shutdown', async (_event, ctx) => {
    resetPromptState()
    stopAnimation(ctx)
  })
}
