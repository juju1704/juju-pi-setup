import { spawn, spawnSync } from "node:child_process";
import { existsSync, lstatSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { StringDecoder } from "node:string_decoder";
import { fileURLToPath } from "node:url";
import { basename, dirname, isAbsolute, join, resolve, sep } from "node:path";

export const AGENT_TOOL_NAME = "Agent";
const REGISTER_GUARD = Symbol.for("agentkit.pi.agentRegistered");
const EXTRA_CHILD_TOOLS = new Set(["grep", "find"]);
const BUILTIN_TOOLS = new Set(["read", "write", "edit", "bash", "grep", "find", "ls"]);
const MAX_AGENT_FILES = 64;
const MAX_AGENT_FILE_BYTES = 128 * 1024;
/** Soft cap on retained raw stdout/stderr; NDJSON parsing continues (do not kill). */
const MAX_CHILD_STREAM_BYTES = 512 * 1024;
/** Cap text returned to the parent model; matches Pi subagent PER_TASK_OUTPUT_CAP. */
const MAX_PARENT_RESULT_BYTES = 50 * 1024;
const MAX_TERMINATION_WAIT_MS = 2000;
const OWNED_KIT_AGENT_STEM = /^ak-[a-z0-9]+(?:-[a-z0-9]+)*-(.+)$/i;

export function inspectAgentPresence(pi) {
  if (pi && pi[REGISTER_GUARD]) return { exists: true, reason: "exists" };
  if (!pi || typeof pi.getAllTools !== "function") {
    return { exists: true, reason: "no-getAllTools" };
  }
  try {
    const tools = pi.getAllTools();
    if (!Array.isArray(tools)) return { exists: true, reason: "malformed-tools" };
    for (const tool of tools) {
      if (!tool || typeof tool !== "object" || typeof tool.name !== "string" || !tool.name.trim()) {
        return { exists: true, reason: "malformed-tools" };
      }
      if (tool.name === AGENT_TOOL_NAME) {
        return { exists: true, reason: "exists" };
      }
    }
    return { exists: false, reason: "absent" };
  } catch {
    return { exists: true, reason: "inspect-failed" };
  }
}

export function agentAlreadyRegistered(pi) {
  return inspectAgentPresence(pi).exists;
}

export function agentParameterSchema() {
  return {
    type: "object",
    properties: {
      subagent_type: {
        type: "string",
        description: "Specialist name from project .pi/agents (frontmatter name or file stem)",
      },
      prompt: {
        type: "string",
        description: "Task for the specialist child pi",
      },
    },
    required: ["subagent_type", "prompt"],
  };
}

export function registerAgentIfAbsent(pi, options = {}) {
  const presence = inspectAgentPresence(pi);
  if (presence.exists) {
    return { registered: false, reason: presence.reason };
  }
  if (!pi || typeof pi.registerTool !== "function") {
    return { registered: false, reason: "no-registerTool" };
  }
  const parameters = options.parameters || agentParameterSchema();
  const discoverRoot = options.rootDir || extensionRoot(options.rootDir);
  if (pi && typeof pi === "object") pi[REGISTER_GUARD] = true;
  try {
    pi.registerTool({
      name: AGENT_TOOL_NAME,
      label: "Agent",
      description: "Spawn a project specialist as a child pi. Uses remapped .pi/agents files.",
      parameters,
      async execute(_toolCallId, params, signal, onUpdate, ctx) {
        return executeAgent(params, signal, ctx, { rootDir: discoverRoot, onUpdate });
      },
    });
  } catch (error) {
    if (pi && typeof pi === "object") delete pi[REGISTER_GUARD];
    throw error;
  }
  return { registered: true };
}

export function childDefaultTools(tools) {
  if (!Array.isArray(tools) || tools.length === 0) return [];
  const cleaned = [];
  const seen = new Set();
  for (const raw of tools) {
    const name = String(raw || "").trim().toLowerCase();
    if (!name || name === "none" || !BUILTIN_TOOLS.has(name) || seen.has(name)) continue;
    seen.add(name);
    cleaned.push(name);
  }
  return cleaned;
}

export function remappedToolsNeedDefaultTools(tools) {
  return childDefaultTools(tools).some((name) => EXTRA_CHILD_TOOLS.has(name));
}

export function getPiInvocation(args) {
  const currentScript = process.argv[1];
  const isBunVirtualScript = typeof currentScript === "string" && currentScript.startsWith("/$bunfs/root/");
  if (currentScript && !isBunVirtualScript && existsSync(currentScript)) {
    return { command: process.execPath, args: [currentScript, ...args] };
  }
  const execName = basename(process.execPath).toLowerCase();
  if (!/^(node|bun)(\.exe)?$/.test(execName)) {
    return { command: process.execPath, args: [...args] };
  }
  return { command: "pi", args: [...args] };
}

export function buildChildPiSpawn(options = {}) {
  const childArgs = ["--mode", "json", "-p", "--no-session", "--approve"];
  const defaultTools = childDefaultTools(options.tools);
  if (options.toolsNone) {
    childArgs.push("--no-tools");
  } else {
    const excluded = ["Agent"];
    if (Array.isArray(options.disallowedTools)) {
      for (const raw of options.disallowedTools) {
        const name = String(raw || "").trim().toLowerCase();
        if (name && BUILTIN_TOOLS.has(name) && !excluded.includes(name)) excluded.push(name);
      }
    }
    childArgs.push("--exclude-tools", excluded.join(","));
    if (defaultTools.length > 0) {
      childArgs.push("--tools", defaultTools.join(","));
    }
  }
  if (typeof options.model === "string" && options.model && options.model !== "inherit") {
    childArgs.push("--model", options.model);
  }
  if (typeof options.systemPromptPath === "string" && options.systemPromptPath) {
    childArgs.push("--append-system-prompt", options.systemPromptPath);
  }
  childArgs.push(String(options.prompt || ""));
  const invocation = getPiInvocation(childArgs);
  return {
    command: invocation.command,
    args: invocation.args,
    defaultTools,
  };
}

/** Resolve child --model: keep a Pi-supported pin, else inherit the parent session model. */
export function resolveChildPiModel(agentModel, ctx) {
  const pinned = typeof agentModel === "string" ? agentModel.trim() : "";
  if (pinned && pinned !== "inherit") return pinned;
  const model = ctx?.model && typeof ctx.model === "object" ? ctx.model : null;
  if (!model) return "";
  const id = typeof model.id === "string" ? model.id.trim() : "";
  if (!id) return "";
  if (id.includes("/")) return id;
  const provider =
    (typeof model.provider === "string" && model.provider.trim()) ||
    (typeof model.providerName === "string" && model.providerName.trim()) ||
    "";
  if (provider) return `${provider}/${id}`;
  return id;
}

export function parseAgentMarkdown(text, fileName) {
  const fileStem = String(fileName || "").replace(/\.md$/i, "");
  const source = String(text || "");
  const parsed = splitFrontmatter(source);
  const fields = parseFrontmatterFields(parsed.frontmatter);
  const toolsNone = fields.toolsNone === true;
  const tools = toolsNone ? [] : childDefaultTools(fields.tools);
  const name = typeof fields.name === "string" && fields.name ? fields.name : fileStem;
  return {
    name,
    description: typeof fields.description === "string" ? fields.description : "",
    model: typeof fields.model === "string" ? fields.model : "",
    tools,
    toolsNone,
    disallowedTools: childDefaultTools(fields.disallowedTools),
    body: parsed.body,
    fileStem,
    fileName: String(fileName || ""),
  };
}

export function agentIdentityMatches(agent, subagentType) {
  const want = String(subagentType || "").trim();
  if (!want || !agent) return false;
  const lower = want.toLowerCase();
  if (String(agent.name || "").toLowerCase() === lower) return true;
  const stem = String(agent.fileStem || "");
  if (stem.toLowerCase() === lower) return true;
  const owned = stem.match(OWNED_KIT_AGENT_STEM);
  if (owned && owned[1].toLowerCase() === lower) return true;
  return false;
}

export function discoverProjectAgents(rootDir) {
  const dir = projectAgentsDir(rootDir);
  if (!dir) return [];
  let dirInfo;
  try { dirInfo = lstatSync(dir); } catch { return []; }
  if (!dirInfo.isDirectory() || dirInfo.isSymbolicLink()) return [];
  let entries;
  try { entries = readdirSync(dir); } catch { return []; }
  const agents = [];
  for (const name of entries) {
    if (!name.toLowerCase().endsWith(".md") || name.includes("\0")) continue;
    if (agents.length >= MAX_AGENT_FILES) break;
    const inspected = inspectAgentFile(dir, name);
    if (inspected) agents.push(inspected);
  }
  return agents;
}

export function resolveProjectAgent(agents, subagentType) {
  const list = agents || [];
  const matches = list.filter((agent) => agentIdentityMatches(agent, subagentType));
  const available = list.map((agent) => agent.name || agent.fileStem).filter(Boolean);
  if (matches.length === 0) return { agent: null, ambiguous: false, matches, available };
  if (matches.length > 1) return { agent: null, ambiguous: true, matches, available };
  return { agent: matches[0], ambiguous: false, matches, available };
}

export function formatAgentIdentity(agent) {
  const name = agent?.name || agent?.fileStem || "unknown";
  if (agent?.fileName && agent.fileName !== `${name}.md`) return `${name} (${agent.fileName})`;
  return name;
}

/** Prefix final Agent tool text so DONE panels keep the same identity as live progress. */
export function formatAgentDoneText(agentLabel, body) {
  const label = String(agentLabel || "agent").trim() || "agent";
  const text = String(body ?? "").trim() || "(no output)";
  const header = `[${label}]`;
  if (text === header || text.startsWith(`${header}\n`) || text.startsWith(`${header} `)) return text;
  return `${header}\n${text}`;
}

export function interpretChildPiResult(result) {
  if (!result || typeof result.code !== "number") {
    throw new Error("child pi produced no result");
  }
  if (result.code !== 0) {
    throw new Error(String(result.stderr || "").trim() || `child pi exited ${result.code}`);
  }
  return result.text || "(no output)";
}

/**
 * Bound assistant text returned to the parent model (Pi subagent example:
 * keep the head, mark omission, preserve full text in tool details).
 */
export function truncateParentAgentText(output) {
  const text = String(output || "");
  const byteLength = Buffer.byteLength(text, "utf8");
  if (byteLength <= MAX_PARENT_RESULT_BYTES) {
    return { text, truncated: false, omittedBytes: 0, full: text };
  }
  let truncated = text.slice(0, MAX_PARENT_RESULT_BYTES);
  while (Buffer.byteLength(truncated, "utf8") > MAX_PARENT_RESULT_BYTES) {
    truncated = truncated.slice(0, -1);
  }
  const omittedBytes = byteLength - Buffer.byteLength(truncated, "utf8");
  return {
    text: `${truncated}\n\n[Output truncated: ${omittedBytes} bytes omitted. Full output preserved in tool details.]`,
    truncated: true,
    omittedBytes,
    full: text,
  };
}

function extensionRoot(rootDir) {
  if (rootDir instanceof URL) return fileURLToPath(rootDir);
  if (typeof rootDir === "string" && rootDir) return resolve(rootDir);
  return resolve(dirname(fileURLToPath(import.meta.url)));
}

function projectAgentsDir(rootDir) {
  const extensionsDir = dirname(extensionRoot(rootDir));
  if (basename(extensionsDir) !== "extensions") return "";
  const piDir = dirname(extensionsDir);
  if (basename(piDir) !== ".pi") return "";
  return join(piDir, "agents");
}

function inspectAgentFile(dir, fileName) {
  const absolute = resolve(dir, fileName);
  if (!isAbsolute(absolute) || (absolute !== dir && !absolute.startsWith(dir + sep))) return null;
  let info;
  try { info = lstatSync(absolute); } catch { return null; }
  if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_AGENT_FILE_BYTES) return null;
  let text;
  try { text = readFileSync(absolute, "utf8"); } catch { return null; }
  if (Buffer.byteLength(text, "utf8") > MAX_AGENT_FILE_BYTES) return null;
  return parseAgentMarkdown(text, fileName);
}

function splitFrontmatter(text) {
  const newline = text.startsWith("---\r\n") ? "\r\n" : (text.startsWith("---\n") ? "\n" : "");
  if (!newline) return { frontmatter: "", body: text };
  const close = text.indexOf(`${newline}---`, 4);
  if (close < 0) return { frontmatter: "", body: text };
  return {
    frontmatter: text.slice(4, close),
    body: text.slice(close + newline.length + 3).replace(/^\r?\n/, ""),
  };
}

function parseFrontmatterFields(frontmatter) {
  const fields = { tools: [], disallowedTools: [], toolsNone: false };
  let currentKey = "";
  for (const rawLine of String(frontmatter || "").split(/\r?\n/)) {
    const line = rawLine.replace(/\t/g, "  ");
    const keyed = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (keyed) {
      currentKey = keyed[1];
      const value = keyed[2].trim();
      assignFrontmatterValue(fields, currentKey, value);
      continue;
    }
    if (currentKey && /^\s+-\s+\S/.test(line)) {
      assignFrontmatterValue(fields, currentKey, line.replace(/^\s+-\s+/, "").trim(), true);
    }
  }
  return fields;
}

function assignFrontmatterValue(fields, key, raw, append = false) {
  const value = unquoteFrontmatter(raw);
  if (key === "name" && !append) fields.name = value;
  else if (key === "description" && !append) fields.description = value;
  else if (key === "model" && !append) fields.model = value;
  else if (key === "tools" || key === "allowed-tools" || key === "allowedTools") {
    if (!append && (value === "none" || value === "")) {
      fields.toolsNone = value === "none";
      if (!append) fields.tools = [];
      return;
    }
    const tokens = splitToolTokens(value);
    if (!append) fields.tools = tokens;
    else fields.tools.push(...tokens);
  } else if (key === "disallowed_tools" || key === "disallowed-tools" || key === "disallowedTools") {
    const tokens = splitToolTokens(value);
    if (!append) fields.disallowedTools = tokens;
    else fields.disallowedTools.push(...tokens);
  }
}

function unquoteFrontmatter(value) {
  const trimmed = String(value || "").trim();
  if (trimmed.length >= 2 && ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

function splitToolTokens(raw) {
  return String(raw || "")
    .replace(/^\[/, "")
    .replace(/\]$/, "")
    .split(",")
    .map((part) => unquoteFrontmatter(part))
    .filter(Boolean);
}

function taskkillPath() {
  const rootKey = Object.keys(process.env).find((key) => ["systemroot", "windir"].includes(key.toLowerCase()));
  return rootKey && process.env[rootKey] ? join(process.env[rootKey], "System32", "taskkill.exe") : "taskkill.exe";
}

async function terminateProcessTree(child) {
  if (!child.pid) return;
  if (process.platform === "win32") {
    await new Promise((done) => {
      let finished = false;
      const settle = () => { if (!finished) { finished = true; done(); } };
      try {
        const killer = spawn(taskkillPath(), ["/pid", String(child.pid), "/T", "/F"], {
          shell: false, windowsHide: true, stdio: "ignore",
        });
        const timer = setTimeout(() => { try { killer.kill("SIGKILL"); } catch { /* ignore */ } settle(); }, MAX_TERMINATION_WAIT_MS);
        const finish = () => { clearTimeout(timer); settle(); };
        killer.once("error", finish);
        killer.once("close", finish);
      } catch { settle(); }
    });
    try { child.kill("SIGKILL"); } catch { /* ignore */ }
    return;
  }
  const pid = child.pid;
  const descendants = unixDescendantPids(pid);
  try { process.kill(-pid, "SIGKILL"); } catch { /* ignore */ }
  try { child.kill("SIGKILL"); } catch { /* ignore */ }
  for (const descendant of descendants) {
    try { process.kill(descendant, "SIGKILL"); } catch { /* ignore */ }
  }
}

function unixDescendantPids(rootPid) {
  const listed = spawnSync("ps", ["-eo", "pid=,ppid="], { encoding: "utf8", timeout: 1000, windowsHide: true });
  if (listed.error || listed.status !== 0 || !listed.stdout) return [];
  const byParent = new Map();
  for (const line of listed.stdout.split("\n")) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 2) continue;
    const pid = Number(parts[0]);
    const ppid = Number(parts[1]);
    if (!Number.isInteger(pid) || !Number.isInteger(ppid) || pid <= 0) continue;
    const siblings = byParent.get(ppid);
    if (siblings) siblings.push(pid);
    else byParent.set(ppid, [pid]);
  }
  const out = [];
  const queue = [rootPid];
  while (queue.length) {
    const next = byParent.get(queue.pop());
    if (!next) continue;
    for (const childPid of next) {
      out.push(childPid);
      queue.push(childPid);
    }
  }
  return out;
}

function extractAssistantText(messages) {
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (!message || message.role !== "assistant" || !Array.isArray(message.content)) continue;
    for (const part of message.content) {
      if (part && part.type === "text" && typeof part.text === "string" && part.text.trim()) return part.text;
    }
  }
  return "";
}

/** Compact live progress for parent TUI (Pi subagent onUpdate pattern). */
export function formatAgentProgress(messages, agentName, toolLedger) {
  const name = String(agentName || "agent").trim() || "agent";
  const items = [];
  // toolResult messages carry toolCallId but not args — resolve from prior toolCall
  // parts and/or the live tool_execution_* ledger (authoritative for bash command).
  const argsByCallId = new Map();
  const itemIndexByCallId = new Map();
  const rememberArgs = (callId, toolName, args) => {
    if (!callId) return;
    const prev = lookupToolLedger(argsByCallId, callId) || lookupToolLedger(toolLedger, callId);
    const merged = mergeToolArgs(prev?.args, args);
    const entry = { toolName: toolName || prev?.toolName || "tool", args: merged };
    for (const key of callIdKeys(callId)) argsByCallId.set(key, entry);
  };
  const upsertToolLine = (callId, line) => {
    const existingIndex = callId ? findLedgerIndex(itemIndexByCallId, callId) : undefined;
    if (existingIndex !== undefined) {
      items[existingIndex] = line;
      return;
    }
    if (callId) {
      for (const key of callIdKeys(callId)) itemIndexByCallId.set(key, items.length);
    }
    items.push(line);
  };
  for (const message of messages || []) {
    if (!message || typeof message !== "object") continue;
    if (message.role === "assistant" && Array.isArray(message.content)) {
      for (const part of message.content) {
        if (!part || typeof part !== "object") continue;
        if (part.type === "toolCall" || part.type === "tool_use" || part.type === "functionCall") {
          const toolName = String(part.name || part.toolName || "tool").trim() || "tool";
          const callId = String(part.id || part.toolCallId || "").trim();
          const ledgerHit = lookupToolLedger(toolLedger, callId) || lookupToolLedger(argsByCallId, callId);
          const args = mergeToolArgs(ledgerHit?.args, toolCallArgs(part));
          rememberArgs(callId, toolName, args);
          upsertToolLine(callId, `→ ${formatToolProgressLine(toolName, args)}`);
          continue;
        }
        if (part.type === "text" && typeof part.text === "string" && part.text.trim()) {
          const preview = part.text.trim().replace(/\s+/g, " ");
          items.push(preview.length > 160 ? `${preview.slice(0, 157)}…` : preview);
        }
      }
      continue;
    }
    if (message.role === "toolResult" || message.role === "tool") {
      const callId = String(message.toolCallId || message.id || "").trim();
      const cached = lookupToolLedger(argsByCallId, callId) || lookupToolLedger(toolLedger, callId);
      const toolName = String(message.toolName || message.name || cached?.toolName || "").trim();
      if (!toolName) continue;
      const args = mergeToolArgs(cached?.args, toolCallArgs(message));
      rememberArgs(callId, toolName, args);
      upsertToolLine(callId, `✓ ${formatToolProgressLine(toolName, args)}`);
    }
  }
  // tool_execution_start can land before message_end; surface those pending tools too.
  if (toolLedger && typeof toolLedger.values === "function") {
    const seen = new Set();
    for (const entry of toolLedger.values()) {
      if (!entry || seen.has(entry)) continue;
      seen.add(entry);
      const callId = String(entry.callId || "").trim();
      if (callId && findLedgerIndex(itemIndexByCallId, callId) !== undefined) continue;
      const toolName = String(entry.toolName || "tool").trim() || "tool";
      const line = formatToolProgressLine(toolName, entry.args || {});
      upsertToolLine(callId, `${entry.done ? "✓" : "→"} ${line}`);
    }
  }
  const recent = items.slice(-10);
  if (recent.length === 0) return `[${name}] running…`;
  return `[${name}]\n${recent.join("\n")}`;
}

export function callIdKeys(callId) {
  const value = String(callId || "").trim();
  if (!value) return [];
  const keys = [value];
  if (value.includes("|")) {
    for (const part of value.split("|")) {
      const trimmed = part.trim();
      if (trimmed && !keys.includes(trimmed)) keys.push(trimmed);
    }
  }
  return keys;
}

export function lookupToolLedger(ledger, callId) {
  if (!ledger || typeof ledger.get !== "function") return undefined;
  for (const key of callIdKeys(callId)) {
    if (ledger.has(key)) return ledger.get(key);
  }
  const needle = String(callId || "").trim();
  if (!needle || typeof ledger.entries !== "function") return undefined;
  for (const [key, entry] of ledger.entries()) {
    if (!key || !entry) continue;
    if (needle.includes(String(key)) || String(key).includes(needle)) return entry;
  }
  return undefined;
}

function findLedgerIndex(indexByCallId, callId) {
  for (const key of callIdKeys(callId)) {
    if (indexByCallId.has(key)) return indexByCallId.get(key);
  }
  return undefined;
}

function mergeToolArgs(base, next) {
  const left = base && typeof base === "object" && !Array.isArray(base) ? base : {};
  const right = next && typeof next === "object" && !Array.isArray(next) ? next : {};
  const merged = { ...left, ...right };
  // toolCall message_end can arrive with empty args while tool_execution_start
  // already carried the real values — never let empties wipe richer ledger data.
  for (const [key, value] of Object.entries(left)) {
    const current = merged[key];
    const empty = current === undefined || current === null || current === ""
      || (Array.isArray(current) && current.length === 0);
    if (!empty) continue;
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value) && value.length === 0) continue;
    merged[key] = value;
  }
  return merged;
}

/** Live registry filled from child `tool_execution_start` / `tool_execution_end`. */
export function noteToolExecution(ledger, event) {
  if (!ledger || !event || typeof event !== "object") return;
  const callId = String(event.toolCallId || event.id || "").trim();
  if (!callId) return;
  const existing = lookupToolLedger(ledger, callId) || {
    callId,
    toolName: "tool",
    args: {},
    done: false,
  };
  if (event.toolName || event.name) {
    existing.toolName = String(event.toolName || event.name).trim() || existing.toolName;
  }
  if (event.args || event.arguments || event.input) {
    existing.args = mergeToolArgs(existing.args, toolCallArgs(event));
  }
  if (event.type === "tool_execution_end" || event.done === true) {
    existing.done = true;
  }
  existing.callId = existing.callId || callId;
  for (const key of callIdKeys(callId)) ledger.set(key, existing);
}

function toolCallArgs(part) {
  if (!part || typeof part !== "object") return {};
  if (part.arguments && typeof part.arguments === "object" && !Array.isArray(part.arguments)) return part.arguments;
  if (part.input && typeof part.input === "object" && !Array.isArray(part.input)) return part.input;
  if (part.args && typeof part.args === "object" && !Array.isArray(part.args)) return part.args;
  if (typeof part.arguments === "string") {
    try {
      const parsed = JSON.parse(part.arguments);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
    } catch {
      /* ignore */
    }
  }
  return {};
}

function shortenProgressPath(raw) {
  const value = String(raw || "").trim();
  if (!value) return "…";
  const parts = value.replace(/\\/g, "/").split("/").filter(Boolean);
  if (parts.length <= 3) return value;
  return `…/${parts.slice(-3).join("/")}`;
}

function progressFilePath(input) {
  return shortenProgressPath(input.file_path || input.path || input.filePath || "");
}

function editProgressCount(input) {
  if (Array.isArray(input.edits) && input.edits.length > 0) return input.edits.length;
  if (typeof input.oldText === "string" || typeof input.newText === "string") return 1;
  return 0;
}

/** Plain-text tool summary aligned with Pi built-in tool call rendering. */
export function formatToolProgressLine(toolName, args) {
  const name = String(toolName || "tool").trim().toLowerCase() || "tool";
  const input = args && typeof args === "object" ? args : {};
  switch (name) {
    case "bash": {
      const command = String(input.command || input.cmd || "").trim().replace(/\s+/g, " ");
      if (!command) return "bash";
      return `$ ${command.length > 100 ? `${command.slice(0, 97)}…` : command}`;
    }
    case "read": {
      const filePath = progressFilePath(input);
      const offset = input.offset;
      const limit = input.limit;
      if (offset !== undefined || limit !== undefined) {
        const start = offset ?? 1;
        const end = limit !== undefined ? Number(start) + Number(limit) - 1 : "";
        return `read ${filePath}:${start}${end !== "" ? `-${end}` : ""}`;
      }
      return `read ${filePath}`;
    }
    case "write": {
      const filePath = progressFilePath(input);
      const content = typeof input.content === "string" ? input.content : "";
      const lines = content ? content.split("\n").length : 0;
      return lines > 1 ? `write ${filePath} (${lines} lines)` : `write ${filePath}`;
    }
    case "edit": {
      const filePath = progressFilePath(input);
      const count = editProgressCount(input);
      return count > 1 ? `edit ${filePath} (${count} edits)` : `edit ${filePath}`;
    }
    case "ls": {
      const filePath = shortenProgressPath(input.path || ".");
      return input.limit !== undefined ? `ls ${filePath} (limit ${input.limit})` : `ls ${filePath}`;
    }
    case "find": {
      const pattern = String(input.pattern || "*").trim() || "*";
      let line = `find ${pattern} in ${shortenProgressPath(input.path || ".")}`;
      if (input.limit !== undefined) line += ` (limit ${input.limit})`;
      return line;
    }
    case "grep": {
      const pattern = String(input.pattern || "").trim();
      let line = `grep /${pattern}/ in ${shortenProgressPath(input.path || ".")}`;
      const glob = String(input.glob || "").trim();
      if (glob) line += ` (${glob})`;
      if (input.limit !== undefined) line += ` limit ${input.limit}`;
      return line;
    }
    default: {
      try {
        const preview = JSON.stringify(input);
        if (!preview || preview === "{}") return name;
        return `${name} ${preview.length > 80 ? `${preview.slice(0, 77)}…` : preview}`;
      } catch {
        return name;
      }
    }
  }
}

export async function runChildPi(spawnPlan, options = {}) {
  return new Promise((resolveResult, reject) => {
    let stdout = "";
    let stderr = "";
    let outputBytes = 0;
    let streamCapped = false;
    let pendingError;
    let terminating = false;
    let settled = false;
    let terminationPromise = Promise.resolve();
    let terminationTimer;
    const stdoutDecoder = new StringDecoder("utf8");
    const stderrDecoder = new StringDecoder("utf8");
    const messages = [];
    const toolLedger = new Map();
    let buffer = "";
    const onProgress = typeof options.onProgress === "function" ? options.onProgress : null;
    const child = spawn(spawnPlan.command, spawnPlan.args, {
      shell: false,
      cwd: options.cwd,
      env: options.env || process.env,
      detached: process.platform !== "win32",
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const cleanup = () => {
      clearTimeout(terminationTimer);
      if (options.signal) options.signal.removeEventListener("abort", abort);
    };
    const requestTermination = (error) => {
      if (!pendingError) pendingError = error;
      if (terminating) return;
      terminating = true;
      child.stdout.pause();
      child.stderr.pause();
      terminationPromise = terminateProcessTree(child);
      terminationTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        child.stdout.destroy();
        child.stderr.destroy();
        reject(pendingError);
      }, MAX_TERMINATION_WAIT_MS);
    };
    const abort = () => requestTermination(new Error("child pi aborted"));
    const emitProgress = () => {
      if (!onProgress) return;
      try {
        onProgress({
          messages: messages.slice(),
          toolLedger,
          text: extractAssistantText(messages),
        });
      } catch {
        /* ignore UI callback failures */
      }
    };
    const consumeLine = (line) => {
      if (!line.trim()) return;
      let event;
      try { event = JSON.parse(line); } catch { return; }
      // Pi JSON mode emits tool_execution_start with args (authoritative for bash).
      if (event?.type === "tool_execution_start" || event?.type === "tool_execution_update") {
        noteToolExecution(toolLedger, event);
        emitProgress();
        return;
      }
      if (event?.type === "tool_execution_end") {
        noteToolExecution(toolLedger, event);
        emitProgress();
        return;
      }
      if (event?.type === "message_end" && event.message) {
        messages.push(event.message);
        emitProgress();
        return;
      }
      // Legacy alias some examples used; keep for forward compatibility.
      if (event?.type === "tool_result_end" && event.message) {
        messages.push(event.message);
        emitProgress();
      }
    };
    const append = (stream, chunk) => {
      outputBytes += chunk.length;
      if (stream === "stdout") {
        // Always parse NDJSON so the final assistant text survives large tool dumps.
        buffer += chunk.toString();
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) consumeLine(line);
        if (!streamCapped) {
          stdout += stdoutDecoder.write(chunk);
          if (outputBytes > MAX_CHILD_STREAM_BYTES) streamCapped = true;
        }
        return;
      }
      if (!streamCapped) {
        stderr += stderrDecoder.write(chunk);
        if (outputBytes > MAX_CHILD_STREAM_BYTES) streamCapped = true;
      }
    };
    child.stdout.on("data", (chunk) => append("stdout", chunk));
    child.stderr.on("data", (chunk) => append("stderr", chunk));
    child.once("error", (error) => requestTermination(error));
    child.once("close", async (code) => {
      if (settled) return;
      if (!streamCapped) {
        stdout += stdoutDecoder.end();
        stderr += stderrDecoder.end();
      } else {
        stdoutDecoder.end();
        stderrDecoder.end();
      }
      if (buffer.trim()) consumeLine(buffer);
      await terminationPromise;
      if (settled) return;
      settled = true;
      cleanup();
      if (pendingError) reject(pendingError);
      else {
        resolveResult({
          stdout,
          stderr,
          code: code ?? -1,
          messages,
          text: extractAssistantText(messages),
          streamCapped,
        });
      }
    });
    if (options.signal) {
      if (options.signal.aborted) abort();
      else options.signal.addEventListener("abort", abort, { once: true });
    }
  });
}

async function executeAgent(params, signal, ctx, options = {}) {
  const subagentType = typeof params?.subagent_type === "string" ? params.subagent_type.trim() : "";
  const prompt = typeof params?.prompt === "string" ? params.prompt : "";
  if (!subagentType || !prompt) {
    throw new Error("Agent requires subagent_type and prompt.");
  }
  const root = options.rootDir || extensionRoot();
  const agents = discoverProjectAgents(root);
  const resolved = resolveProjectAgent(agents, subagentType);
  if (resolved.ambiguous) {
    const names = resolved.matches.map(formatAgentIdentity).join(", ");
    throw new Error(`Ambiguous subagent_type "${subagentType}". Matches: ${names}. Use a kit-scoped name.`);
  }
  if (!resolved.agent) {
    const available = resolved.available.length ? resolved.available.join(", ") : "none";
    throw new Error(`Unknown subagent_type "${subagentType}". Available: ${available}.`);
  }
  const agent = resolved.agent;
  const agentLabel = formatAgentIdentity(agent);
  const onUpdate = typeof options.onUpdate === "function" ? options.onUpdate : null;
  const emitPartial = (messages, toolLedger) => {
    if (!onUpdate) return;
    const text = formatAgentProgress(messages, agentLabel, toolLedger);
    try {
      onUpdate({
        content: [{ type: "text", text }],
        details: { agent: agent.name, agentFile: agent.fileName || "", status: "running" },
      });
    } catch {
      /* ignore */
    }
  };
  let tmpDir = "";
  let systemPromptPath = "";
  try {
    if (agent.body.trim()) {
      tmpDir = mkdtempSync(join(tmpdir(), "agentkit-agent-"));
      systemPromptPath = join(tmpDir, "system-prompt.md");
      writeFileSync(systemPromptPath, agent.body, { encoding: "utf8", mode: 0o600 });
    }
    const spawnPlan = buildChildPiSpawn({
      tools: agent.tools,
      toolsNone: agent.toolsNone,
      disallowedTools: agent.disallowedTools,
      model: resolveChildPiModel(agent.model, ctx),
      systemPromptPath,
      prompt,
    });
    emitPartial([]);
    const result = await runChildPi(spawnPlan, {
      cwd: ctx?.cwd,
      signal,
      onProgress: ({ messages, toolLedger }) => emitPartial(messages, toolLedger),
    });
    const bounded = truncateParentAgentText(
      formatAgentDoneText(agentLabel, interpretChildPiResult(result)),
    );
    const details = {
      defaultTools: spawnPlan.defaultTools,
      exitCode: result.code,
      agent: agent.name,
      agentFile: agent.fileName || "",
      streamCapped: Boolean(result.streamCapped),
      truncated: bounded.truncated,
      status: "done",
    };
    if (bounded.truncated) {
      details.fullText = bounded.full;
      details.omittedBytes = bounded.omittedBytes;
    }
    return {
      content: [{ type: "text", text: bounded.text }],
      details,
    };
  } finally {
    if (tmpDir) {
      try { rmSync(tmpDir, { recursive: true, force: true }); } catch { /* ignore */ }
    }
  }
}

export function createAgentKitAgent(pi, supplied = {}) {
  const root = extensionRoot(supplied.rootDir);
  const tryRegister = () => registerAgentIfAbsent(pi, { rootDir: root, parameters: supplied.parameters });
  if (typeof pi.on === "function") {
    pi.on("session_start", () => {
      tryRegister();
    });
  }
  return { root, tryRegister };
}

export default function agentKitAgentExtension(pi) {
  createAgentKitAgent(pi);
}
