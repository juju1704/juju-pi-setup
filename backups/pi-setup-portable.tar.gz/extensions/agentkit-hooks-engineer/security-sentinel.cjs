'use strict';

// Pi requires security hooks to fail closed even though the shared Claude hook
// entrypoints preserve their historical fail-open crash wrappers. This preload
// observes only hook-logger crash reporting (or failure to load that logger)
// and upgrades an explicit zero exit to a non-zero runner failure.
const Module = require('node:module');
const path = require('node:path');

let crashed = false;
const originalLoad = Module._load;
Module._load = function agentKitSecurityLoad(request, parent, isMain) {
  const isHookLogger = path.basename(String(request)) === 'hook-logger.cjs';
  try {
    const loaded = originalLoad.apply(this, arguments);
    if (!isHookLogger || !loaded || typeof loaded.logHookCrash !== 'function') return loaded;
    return {
      ...loaded,
      logHookCrash(...args) {
        crashed = true;
        return loaded.logHookCrash(...args);
      },
    };
  } catch (error) {
    if (isHookLogger) crashed = true;
    throw error;
  }
};

const originalExit = process.exit.bind(process);
process.exit = function agentKitSecurityExit(code = process.exitCode || 0) {
  return originalExit(crashed && Number(code) === 0 ? 70 : code);
};

process.on('beforeExit', () => {
  if (crashed && (!process.exitCode || process.exitCode === 0)) process.exitCode = 70;
});
