import { spawn, spawnSync } from "node:child_process";
import { lstatSync, readdirSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { StringDecoder } from "node:string_decoder";
import { fileURLToPath } from "node:url";
import { basename, dirname, isAbsolute, join, resolve, sep } from "node:path";

const ROOT_TOKEN = "${CLAUDE_PLUGIN_ROOT}";
const CONFIG_FILE = "hooks.json";
const MAX_CONFIG_BYTES = 64 * 1024;
// Bound untrusted hook payloads to limit bridge memory and CPU denial of service.
const MAX_PAYLOAD_BYTES = 8 * 1024 * 1024;
const MAX_PAYLOAD_DEPTH = 32;
const MAX_PAYLOAD_NODES = 10_000;
const MAX_GROUPS = 32;
const MAX_HANDLERS_PER_GROUP = 16;
const MAX_HANDLERS = 64;
const MAX_CHILD_TIMEOUT_MS = 5000;
const MAX_PIPELINE_TIMEOUT_MS = 10_000;
const MAX_CHILD_OUTPUT_BYTES = 64 * 1024;
const MAX_PIPELINE_OUTPUT_BYTES = 128 * 1024;
const MAX_HANDLER_CONTEXT_BYTES = 32 * 1024;
const MAX_PIPELINE_CONTEXT_BYTES = 64 * 1024;
const MAX_PIPELINE_CONTEXTS = 16;
const MAX_SESSION_ID_BYTES = 256;
const MAX_PROMPT_BYTES = 128 * 1024;
const MAX_PENDING_PROMPTS = 64;
const MAX_PENDING_CONTEXT_BYTES = 128 * 1024;
const MAX_TERMINATION_WAIT_MS = 2000;
const MAX_STATUSLINE_OUTPUT_BYTES = 16 * 1024;
const FOOTER_GUARD = Symbol.for("agentkit.pi.footerGuard");
const ASK_REGISTER_GUARD = Symbol.for("agentkit.pi.askUserRegistered");
const AGENTKIT_FOOTER_OWNER = "agentkit";
const MAX_ASK_QUESTION_BYTES = 4 * 1024;
const MAX_ASK_OPTIONS = 32;
const MAX_ASK_OPTION_BYTES = 512;
export const ASK_USER_TOOL_NAME = "ask_user";
const PROMPT_CONTEXT_TTL_MS = 5 * 60 * 1000;
const TOOL_NAMES = { read: "Read", write: "Write", edit: "Edit", bash: "Bash" };
const TOOL_MATCHER_KEYS = Object.freeze(Object.keys(TOOL_NAMES));
const TOOL_MATCHERS = new Set(["*", ...TOOL_MATCHER_KEYS]);
const LIFECYCLE_WILDCARD_EVENTS = new Set(["PreCompact", "UserPromptSubmit", "SessionStart", "Stop"]);
const SESSION_START_SOURCES = Object.freeze({
  startup: "startup",
  resume: "resume",
  reload: "clear",
  new: "startup",
  fork: "startup",
});
// Exported so a Go conformance test can prove this mirror still matches
// policy.go. It stays an in-code frozen allowlist on purpose: this bridge is
// the trust anchor for a hooks.json it treats as hostile, and an anchor cannot
// be supplied by the data it validates.
export const EVENT_POLICY = Object.freeze({
  PreCompact: Object.freeze({
    "agent-behavior-linter.cjs": { failureMode: "open", matchers: ["*"] },
    "precompact-capture.cjs": { failureMode: "open", matchers: ["*"] },
  }),
  PreToolUse: Object.freeze({
    "context-firewall.cjs": { failureMode: "open", matchers: ["bash", "read"] },
    "descriptive-name.cjs": { failureMode: "open", matchers: ["write"] },
    "privacy-block.cjs": { failureMode: "closed", matchers: ["read", "write", "edit", "bash"] },
    "scout-block.cjs": { failureMode: "closed", matchers: ["bash", "read"] },
  }),
  PostToolUse: Object.freeze({
    "agent-behavior-linter.cjs": { failureMode: "open", matchers: ["*"] },
    "dev-rules-reminder.cjs": { failureMode: "open", matchers: ["write", "edit"] },
    "plan-format-kanban.cjs": { failureMode: "open", matchers: ["edit", "write"] },
    "usage-quota-cache-refresh.cjs": { failureMode: "open", matchers: ["*"] },
  }),
  UserPromptSubmit: Object.freeze({
    "dev-rules-reminder.cjs": { failureMode: "open", matchers: ["*"] },
    "secret-output-guardrail.cjs": { failureMode: "open", matchers: ["*"] },
    "session-heartbeat.cjs": { failureMode: "open", matchers: ["*"] },
    "simplify-gate.cjs": { failureMode: "open", matchers: ["*"] },
    "usage-quota-cache-refresh.cjs": { failureMode: "open", matchers: ["*"] },
  }),
  SessionStart: Object.freeze({
    "session-heartbeat.cjs": { failureMode: "open", matchers: ["*"] },
    "session-init.cjs": { failureMode: "open", matchers: ["*"] },
  }),
  Stop: Object.freeze({
    "agent-behavior-linter.cjs": { failureMode: "open", matchers: ["*"] },
    "cook-after-plan-reminder.cjs": { failureMode: "open", matchers: ["*"] },
    "session-heartbeat.cjs": { failureMode: "open", matchers: ["*"] },
    "session-state.cjs": { failureMode: "open", matchers: ["*"] },
    "usage-quota-cache-refresh.cjs": { failureMode: "open", matchers: ["*"] },
  }),
});

// The failure-closed floor is derived from EVENT_POLICY rather than restated,
// so a reviewed security gate cannot be weakened in one table and still be
// demanded by the other.
export const REQUIRED_SECURITY_COVERAGE = Object.freeze(Object.fromEntries(
  Object.entries(EVENT_POLICY).flatMap(([eventName, handlers]) => Object.entries(handlers)
    .filter(([, policy]) => policy.failureMode === "closed")
    .map(([id, policy]) => [id, Object.freeze([...expandMatcherSet(eventName, policy.matchers)])])),
));

function extensionRoot(rootDir) {
  if (rootDir instanceof URL) return fileURLToPath(rootDir);
  return resolve(String(rootDir));
}

function byteLength(value) {
  return Buffer.byteLength(value, "utf8");
}

function exactKeys(value, expected, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype) {
    throw new Error(`${label} must be a plain object`);
  }
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const keys = Reflect.ownKeys(descriptors);
  if (keys.length !== expected.length || keys.some((key) => typeof key !== "string" || !expected.includes(key))) {
    throw new Error(`${label} has an invalid schema`);
  }
  for (const key of keys) {
    if (!("value" in descriptors[key]) || !descriptors[key].enumerable) throw new Error(`${label} must contain plain data properties`);
  }
}

function strictArray(value, label, max) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length > max) {
    throw new Error(`${label} must be a bounded array`);
  }
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const keys = Reflect.ownKeys(descriptors);
  if (keys.length !== value.length + 1 || !keys.includes("length")) throw new Error(`${label} has extra properties`);
  for (let index = 0; index < value.length; index += 1) {
    const descriptor = descriptors[String(index)];
    if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) throw new Error(`${label} must contain plain, non-sparse elements`);
  }
}

// "*" selects every Pi tool on a tool-scoped event, so a reviewed bound and a
// declared matcher only compare correctly as tool sets. policy.go mirrors this.
function expandMatcherSet(eventName, matchers) {
  if (LIFECYCLE_WILDCARD_EVENTS.has(eventName)) return new Set(matchers);
  const out = new Set();
  for (const matcher of matchers) {
    if (matcher === "*") {
      for (const tool of TOOL_MATCHER_KEYS) out.add(tool);
      continue;
    }
    out.add(matcher);
  }
  return out;
}

function validateMatcher(eventName, matcher) {
  strictArray(matcher, `${eventName} matcher`, 4);
  if (matcher.length === 0 || matcher.some((item) => typeof item !== "string")) throw new Error(`${eventName} matcher is invalid`);
  if (new Set(matcher).size !== matcher.length) throw new Error(`${eventName} matcher contains duplicates`);
  if (LIFECYCLE_WILDCARD_EVENTS.has(eventName)) {
    if (matcher.length !== 1 || matcher[0] !== "*") throw new Error(`${eventName} requires the reviewed wildcard matcher`);
    return;
  }
  if (matcher.some((item) => !TOOL_MATCHERS.has(item)) || (matcher.includes("*") && matcher.length !== 1)) {
    throw new Error(`${eventName} contains an unreviewed matcher`);
  }
}

// Exported so a Go conformance test can compare this validator's verdict against
// the emitter's, candidate matcher by candidate matcher. Agreeing tables are not
// enough: the two sides also have to read them the same way.
export function validateConfig(config, requireSecurityCoverage = false) {
  exactKeys(config, ["version", "hooks"], "hook config");
  if (config.version !== 1) throw new Error("hook config version must be exactly 1");
  if (config.hooks === null || typeof config.hooks !== "object" || Array.isArray(config.hooks) || Object.getPrototypeOf(config.hooks) !== Object.prototype) {
    throw new Error("hook config hooks must be a plain object");
  }
  const events = Object.keys(config.hooks);
  exactKeys(config.hooks, events, "hook config hooks");
  if (events.some((eventName) => !Object.prototype.hasOwnProperty.call(EVENT_POLICY, eventName))) {
    throw new Error("hook config contains an unknown event");
  }
  let groupCount = 0;
  let handlerCount = 0;
  let scalarBytes = 0;
  const securityCoverage = new Map();
  for (const eventName of events) {
    const groups = config.hooks[eventName];
    strictArray(groups, `${eventName} groups`, MAX_GROUPS);
    groupCount += groups.length;
    if (groupCount > MAX_GROUPS) throw new Error("hook config contains too many groups");
    for (const group of groups) {
      exactKeys(group, ["matcher", "handlers"], `${eventName} group`);
      validateMatcher(eventName, group.matcher);
      scalarBytes += group.matcher.reduce((total, matcher) => total + byteLength(matcher), 0);
      strictArray(group.handlers, `${eventName} handlers`, MAX_HANDLERS_PER_GROUP);
      if (group.handlers.length === 0) throw new Error(`${eventName} group must contain a handler`);
      const groupIDs = new Set();
      for (const handler of group.handlers) {
        exactKeys(handler, ["id", "command", "args", "failureMode"], `${eventName} handler`);
        if (typeof handler.id !== "string" || typeof handler.command !== "string" || typeof handler.failureMode !== "string") {
          throw new Error(`${eventName} handler fields must be strings`);
        }
        const approved = Object.prototype.hasOwnProperty.call(EVENT_POLICY[eventName], handler.id) ? EVENT_POLICY[eventName][handler.id] : undefined;
        const approvedTools = approved ? expandMatcherSet(eventName, approved.matchers) : undefined;
        if (!approved || handler.failureMode !== approved.failureMode || groupIDs.has(handler.id) ||
            [...expandMatcherSet(eventName, group.matcher)].some((matcher) => !approvedTools.has(matcher))) {
          throw new Error(`${eventName} contains an unreviewed handler policy or matcher`);
        }
        groupIDs.add(handler.id);
        if (handler.failureMode === "closed") {
          const covered = securityCoverage.get(handler.id) || new Set();
          for (const matcher of expandMatcherSet(eventName, group.matcher)) covered.add(matcher);
          securityCoverage.set(handler.id, covered);
        }
        scalarBytes += byteLength(handler.id) + byteLength(handler.command) + byteLength(handler.failureMode);
        if (!handler.command || handler.command.includes("\0")) throw new Error(`${handler.id} has an invalid Node command`);
        const executable = handler.command.toLowerCase();
        if (executable !== "node" && executable !== "node.exe") throw new Error(`${handler.id} must use the literal Node interpreter tuple`);
        strictArray(handler.args, `${handler.id} args`, 1);
        const expectedScript = `${ROOT_TOKEN}/hooks/${handler.id}`;
        if (handler.args.length !== 1 || handler.args[0] !== expectedScript) throw new Error(`${handler.id} has an unreviewed Node tuple`);
        scalarBytes += byteLength(handler.args[0]);
        if (scalarBytes > MAX_CONFIG_BYTES) throw new Error("hook config exceeded size limit");
        handlerCount += 1;
        if (handlerCount > MAX_HANDLERS) throw new Error("hook config contains too many handlers");
      }
    }
  }
  if (requireSecurityCoverage) {
    for (const [handlerID, matchers] of Object.entries(REQUIRED_SECURITY_COVERAGE)) {
      const covered = securityCoverage.get(handlerID);
      if (!covered || matchers.some((matcher) => !covered.has(matcher))) {
        throw new Error("hook config omitted required security coverage");
      }
    }
  }
  let encoded;
  try { encoded = JSON.stringify(config); } catch { throw new Error("hook config is not serializable"); }
  if (byteLength(encoded) > MAX_CONFIG_BYTES) throw new Error("hook config exceeded size limit");
  return JSON.parse(encoded);
}

function loadConfig(root) {
  const configPath = resolve(root, CONFIG_FILE);
  const info = lstatSync(configPath);
  if (!info.isFile() || info.isSymbolicLink()) throw new Error("hook config must be a regular non-symlink file");
  if (info.size > MAX_CONFIG_BYTES) throw new Error("hook config exceeded size limit");
  const bytes = readFileSync(configPath);
  if (bytes.length > MAX_CONFIG_BYTES) throw new Error("hook config exceeded size limit");
  return validateConfig(JSON.parse(bytes.toString("utf8")), true);
}

function resolveScalar(value, root) {
  if (!value.includes(ROOT_TOKEN)) return value;
  if (!value.startsWith(ROOT_TOKEN) || value.indexOf(ROOT_TOKEN, ROOT_TOKEN.length) !== -1) {
    throw new Error("unsafe CLAUDE_PLUGIN_ROOT interpolation");
  }
  const suffix = value.slice(ROOT_TOKEN.length);
  if (!suffix.startsWith("/") && !suffix.startsWith("\\")) throw new Error("CLAUDE_PLUGIN_ROOT must reference a contained path");
  const cleanRoot = resolve(root);
  const absolute = resolve(cleanRoot, `.${suffix}`);
  if (!isAbsolute(absolute) || (absolute !== cleanRoot && !absolute.startsWith(cleanRoot + sep))) {
    throw new Error("CLAUDE_PLUGIN_ROOT escaped the extension root");
  }
  return absolute;
}

function serializePayload(payload) {
  const stack = [{ value: payload, depth: 1 }];
  const seen = new Set();
  let nodes = 0;
  let scalarBytes = 0;
  while (stack.length) {
    const { value, depth } = stack.pop();
    nodes += 1;
    if (nodes > MAX_PAYLOAD_NODES) throw new Error("hook payload exceeded node limit");
    if (typeof value === "string") {
      scalarBytes += byteLength(value);
      if (scalarBytes > MAX_PAYLOAD_BYTES) throw new Error("hook payload exceeded size limit");
    }
    if (value === null || typeof value !== "object") continue;
    if (depth > MAX_PAYLOAD_DEPTH) throw new Error("hook payload exceeded depth limit");
    if (seen.has(value)) throw new Error("hook payload must not contain cycles");
    seen.add(value);
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Object.keys(descriptors);
    nodes += keys.length;
    if (nodes > MAX_PAYLOAD_NODES) throw new Error("hook payload exceeded node limit");
    for (const key of keys) {
      const descriptor = descriptors[key];
      if ("value" in descriptor && descriptor.enumerable) stack.push({ value: descriptor.value, depth: depth + 1 });
    }
  }
  let encoded;
  try { encoded = JSON.stringify(payload); } catch { throw new Error("hook payload is not serializable"); }
  if (encoded === undefined || byteLength(encoded) > MAX_PAYLOAD_BYTES) throw new Error("hook payload exceeded size limit");
  return encoded;
}

function copyEnv(name, target) {
  const found = Object.keys(process.env).find((key) => key.toLowerCase() === name.toLowerCase());
  if (found && typeof process.env[found] === "string" && !process.env[found].includes("\0")) target[name] = process.env[found];
}

function minimalPath() {
  // Fail-closed child env: provide a minimal PATH containing only the Node binary
  // directory plus essential system paths. This allows contained hook scripts to
  // spawn Node if needed while preventing access to arbitrary binaries on the user's
  // full PATH.
  const nodeBin = dirname(process.execPath);
  if (process.platform === "win32") {
    const systemRoot = process.env.SystemRoot || process.env.WINDIR || "C:\\Windows";
    return `${nodeBin};${systemRoot}\\System32;${systemRoot}`;
  }
  return `${nodeBin}:/usr/bin:/bin`;
}

function childEnvironment(handler, sessionId) {
  // Fail-closed child env: pass only reviewed environment variables. Do not spread
  // full process.env. Specifically exclude GIT_*, NODE_OPTIONS, credentials, and
  // other potentially-poisoned variables. Pass through AgentKit-specific overrides
  // (AGENTKIT_BIN, AK_INSTALL_DIR, CK_HOOK_LOG_DIR) to support hook instrumentation.
  const env = {};
  const names = process.platform === "win32"
    ? ["SystemRoot", "WINDIR", "ComSpec", "PATHEXT", "TEMP", "TMP", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA"]
    : ["TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "USER", "LOGNAME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME"];
  for (const name of [...names, "HOME", "AGENTKIT_HOME"]) copyEnv(name, env);
  for (const name of ["AGENTKIT_BIN", "AK_INSTALL_DIR", "CK_HOOK_LOG_DIR"]) copyEnv(name, env);
  if (handler.failureMode === "open") copyEnv("PATH", env);
  else env.PATH = minimalPath();
  if (handler.id === "simplify-gate.cjs") copyEnv("CK_SIMPLIFY_DISABLED", env);
  env.PI_SESSION_ID = sessionId;
  return env;
}

function boundedSessionID(value) {
  const sessionId = typeof value === "string" ? value : "";
  if (sessionId.includes("\0") || byteLength(sessionId) > MAX_SESSION_ID_BYTES) throw new Error("Pi session id exceeded limit");
  return sessionId;
}

function taskkillPath() {
  const rootKey = Object.keys(process.env).find((key) => ["systemroot", "windir"].includes(key.toLowerCase()));
  return rootKey && process.env[rootKey] ? join(process.env[rootKey], "System32", "taskkill.exe") : "taskkill.exe";
}

async function terminateProcessTree(child) {
  if (!child.pid) return;
  if (process.platform === "win32") {
    await new Promise((done) => {
      let finished = false;
      const settle = () => { if (!finished) { finished = true; done(); } };
      try {
        const killer = spawn(taskkillPath(), ["/pid", String(child.pid), "/T", "/F"], {
          shell: false, windowsHide: true, stdio: "ignore", env: childEnvironment({ failureMode: "closed" }, ""),
        });
        const timer = setTimeout(() => { try { killer.kill("SIGKILL"); } catch {} settle(); }, MAX_TERMINATION_WAIT_MS);
        const finish = () => { clearTimeout(timer); settle(); };
        killer.once("error", finish);
        killer.once("close", finish);
      } catch { settle(); }
    });
    try { child.kill("SIGKILL"); } catch {}
    return;
  }
  const pid = child.pid;
  const descendants = unixDescendantPids(pid);
  try { process.kill(-pid, "SIGKILL"); } catch {}
  try { child.kill("SIGKILL"); } catch {}
  for (const descendant of descendants) {
    try { process.kill(descendant, "SIGKILL"); } catch {}
  }
}

function unixDescendantPids(rootPid) {
  const listed = spawnSync("ps", ["-eo", "pid=,ppid="], { encoding: "utf8", timeout: 1000, windowsHide: true });
  if (listed.error || listed.status !== 0 || !listed.stdout) return [];
  const byParent = new Map();
  for (const line of listed.stdout.split("\n")) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 2) continue;
    const pid = Number(parts[0]);
    const ppid = Number(parts[1]);
    if (!Number.isInteger(pid) || !Number.isInteger(ppid) || pid <= 0) continue;
    const siblings = byParent.get(ppid);
    if (siblings) siblings.push(pid);
    else byParent.set(ppid, [pid]);
  }
  const out = [];
  const queue = [rootPid];
  while (queue.length) {
    const next = byParent.get(queue.pop());
    if (!next) continue;
    for (const childPid of next) {
      out.push(childPid);
      queue.push(childPid);
    }
  }
  return out;
}

function executeCommand(handler, encodedPayload, options, budget) {
  const script = resolveScalar(handler.args[0], options.root);
  const args = handler.failureMode === "closed"
    ? ["--require", resolve(options.root, "security-sentinel.cjs"), script]
    : [script];
  const timeoutMs = Math.max(1, Math.min(options.timeoutMs, budget.deadline - Date.now()));
  if (budget.deadline <= Date.now()) return Promise.reject(new Error("hook pipeline timed out"));
  for (const signal of options.signals) {
    if (signal?.aborted) return Promise.reject(new Error("hook execution aborted"));
  }
  const env = childEnvironment(handler, options.sessionId);
  return new Promise((resolveResult, reject) => {
    let stdout = "";
    let stderr = "";
    let childOutputBytes = 0;
    let pendingError;
    let terminating = false;
    let settled = false;
    let terminationPromise = Promise.resolve();
    let terminationTimer;
    let closed = false;
    const stdoutDecoder = new StringDecoder("utf8");
    const stderrDecoder = new StringDecoder("utf8");
    // Exact-tuple approval: spawn uses shell: false with process.execPath (the running Node
    // binary's absolute path) and only contained ${CLAUDE_PLUGIN_ROOT}/hooks/<id> scripts.
    // The handler.command field was validated at config load to be literal "node" or "node.exe";
    // that value is never used as a command — process.execPath is always the spawn target.
    const child = spawn(process.execPath, args, {
      shell: false,
      cwd: options.cwd,
      env,
      detached: process.platform !== "win32",
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });
    const cleanup = () => {
      clearTimeout(timer);
      clearTimeout(terminationTimer);
      for (const signal of options.signals) signal?.removeEventListener("abort", abort);
    };
    const requestTermination = (error) => {
      if (!pendingError) pendingError = error;
      if (terminating) return;
      terminating = true;
      child.stdout.pause();
      child.stderr.pause();
      terminationPromise = terminateProcessTree(child);
      terminationTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        child.stdin.destroy();
        child.stdout.destroy();
        child.stderr.destroy();
        reject(pendingError);
      }, MAX_TERMINATION_WAIT_MS);
    };
    const abort = () => requestTermination(new Error("hook execution aborted"));
    const append = (stream, chunk) => {
      childOutputBytes += chunk.length;
      budget.outputBytes += chunk.length;
      if (childOutputBytes > options.maxOutputBytes || budget.outputBytes > MAX_PIPELINE_OUTPUT_BYTES) {
        requestTermination(new Error("hook output exceeded limit"));
        return;
      }
      if (stream === "stdout") stdout += stdoutDecoder.write(chunk);
      else stderr += stderrDecoder.write(chunk);
    };
    child.stdout.on("data", (chunk) => append("stdout", chunk));
    child.stderr.on("data", (chunk) => append("stderr", chunk));
    child.once("error", (error) => requestTermination(error));
    child.once("close", async (code, signal) => {
      closed = true;
      if (settled) return;
      stdout += stdoutDecoder.end();
      stderr += stderrDecoder.end();
      await terminationPromise;
      if (settled) return;
      settled = true;
      cleanup();
      if (pendingError) reject(pendingError);
      else resolveResult({ stdout, stderr, code: code ?? -1, signal });
    });
    for (const signal of options.signals) signal?.addEventListener("abort", abort, { once: true });
    const timer = setTimeout(() => requestTermination(new Error(`hook timed out after ${timeoutMs}ms`)), timeoutMs);
    if (options.signals.some((signal) => signal?.aborted)) abort();
    child.stdin.on("error", (error) => {
      // Unix closed-stdin writes report EPIPE/ECONNRESET; Windows often reports EOF.
      if (!closed && error?.code !== "EPIPE" && error?.code !== "ECONNRESET" && error?.code !== "EOF") {
        requestTermination(error);
      }
    });
    child.stdin.end(encodedPayload);
  });
}

function interpretOutput(result) {
  const stdout = result.stdout.trim();
  let value;
  if (stdout) {
    try { value = JSON.parse(stdout); } catch { value = undefined; }
  }
  const specific = value?.hookSpecificOutput || {};
  const decision = value?.decision === "block" || value?.continue === false || specific.permissionDecision === "deny";
  const context = specific.additionalContext || value?.additionalContext ||
    (typeof value?.systemMessage === "string" ? value.systemMessage : "") ||
    (value === undefined ? stdout : "");
  return {
    block: decision || result.code === 2,
    reason: typeof value?.reason === "string" ? value.reason :
      (typeof specific.permissionDecisionReason === "string" ? specific.permissionDecisionReason : result.stderr.trim() || stdout || "hook blocked the operation"),
    context: typeof context === "string" ? context : "",
    updatedInput: specific.updatedInput || value?.updatedInput,
  };
}

function matchingGroups(config, eventName, toolName) {
  return (config.hooks[eventName] || []).filter((group) => group.matcher.includes("*") || (toolName && group.matcher.includes(toolName.toLowerCase())));
}

async function runPipeline(config, eventName, payload, toolName, options) {
  const groups = matchingGroups(config, eventName, toolName);
  const contexts = [];
  let contextBytes = 0;
  let updatedInput;
  let encodedPayload;
  try { encodedPayload = serializePayload(payload); } catch (error) {
    const closed = groups.some((group) => group.handlers.some((handler) => handler.failureMode === "closed"));
    return { block: closed, reason: closed ? `hook payload failed closed: ${error.message}` : "", contexts };
  }
  const budget = { deadline: Date.now() + options.pipelineTimeoutMs, outputBytes: 0 };
  for (const group of groups) {
    for (const handler of group.handlers) {
      if (updatedInput) {
        payload.tool_input = updatedInput;
        try { encodedPayload = serializePayload(payload); } catch (error) {
          if (handler.failureMode === "closed") return { block: true, reason: `${handler.id} failed closed: ${error.message}`, contexts };
          continue;
        }
      }
      let result;
      try { result = await executeCommand(handler, encodedPayload, options, budget); } catch (error) {
        if (handler.failureMode === "closed") {
          return { block: true, reason: `${handler.id} failed closed: ${error instanceof Error ? error.message : String(error)}`, contexts };
        }
        continue;
      }
      const interpreted = interpretOutput(result);
      if (interpreted.context) {
        const bytes = byteLength(interpreted.context);
        if (bytes > MAX_HANDLER_CONTEXT_BYTES || contextBytes + bytes > MAX_PIPELINE_CONTEXT_BYTES || contexts.length >= MAX_PIPELINE_CONTEXTS) {
          if (handler.failureMode === "closed") return { block: true, reason: `${handler.id} failed closed: hook context exceeded limit`, contexts };
        } else {
          contextBytes += bytes;
          contexts.push(interpreted.context);
        }
      }
      if (interpreted.updatedInput && typeof interpreted.updatedInput === "object" && !Array.isArray(interpreted.updatedInput)) updatedInput = interpreted.updatedInput;
      if (interpreted.block) return { block: true, reason: interpreted.reason, contexts, updatedInput };
      if (result.code !== 0 && handler.failureMode === "closed") {
        return { block: true, reason: `${handler.id} failed closed with exit ${result.code}`, contexts, updatedInput };
      }
    }
  }
  return { block: false, contexts, updatedInput };
}

function basePayload(eventName, ctx, sessionId) {
  return { hook_event_name: eventName, session_id: sessionId, cwd: ctx.cwd };
}

function sendContexts(pi, contexts) {
  for (const content of contexts) {
    if (content) pi.sendMessage({ customType: "agentkit-hook", content, display: false }, { deliverAs: "steer" });
  }
}

function boundedOption(value, fallback, maximum, name) {
  if (value === undefined) return fallback;
  if (!Number.isInteger(value) || value < 1 || value > maximum) throw new Error(`${name} is outside its approved bound`);
  return value;
}

function sessionStartSource(reason) {
  if (typeof reason === "string" && Object.prototype.hasOwnProperty.call(SESSION_START_SOURCES, reason)) {
    return SESSION_START_SOURCES[reason];
  }
  return "unknown";
}

function statuslineChildEnvironment(sessionId) {
  const env = {};
  const names = process.platform === "win32"
    ? ["SystemRoot", "WINDIR", "ComSpec", "PATHEXT", "TEMP", "TMP", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA"]
    : ["TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "USER", "LOGNAME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME"];
  for (const name of [...names, "HOME", "AGENTKIT_HOME", "PATH", "NO_COLOR", "FORCE_COLOR", "COLUMNS"]) copyEnv(name, env);
  for (const name of ["AGENTKIT_BIN", "AK_INSTALL_DIR", "CK_HOOK_LOG_DIR"]) copyEnv(name, env);
  env.PI_SESSION_ID = sessionId;
  return env;
}

function containedStatuslinePath(root, candidate) {
  const cleanRoot = resolve(root);
  const name = basename(String(candidate));
  if (!/^ak-[a-z0-9]+(?:-[a-z0-9]+)*-statusline\.cjs$/.test(name)) {
    throw new Error("statusline script name is not owned");
  }
  const absolute = resolve(cleanRoot, name);
  if (!isAbsolute(absolute) || (absolute !== cleanRoot && !absolute.startsWith(cleanRoot + sep))) {
    throw new Error("statusline script escaped the extension root");
  }
  const info = lstatSync(absolute);
  if (!info.isFile() || info.isSymbolicLink()) throw new Error("statusline script must be a regular non-symlink file");
  return absolute;
}

export function resolveOwnedStatuslineScript(root) {
  const dirName = basename(resolve(root));
  if (!dirName.startsWith("agentkit-hooks-")) return "";
  const kit = dirName.slice("agentkit-hooks-".length);
  if (!kit || kit.includes("\0") || kit.includes("/") || kit.includes("\\") || kit.includes("..")) return "";
  try {
    return containedStatuslinePath(root, join(root, `ak-${kit}-statusline.cjs`));
  } catch {
    return "";
  }
}

export function synthesizeClaudeStatuslinePayload(ctx) {
  let sessionId = "";
  try { sessionId = boundedSessionID(ctx?.sessionManager?.getSessionId?.()); } catch { sessionId = ""; }
  const model = ctx?.model && typeof ctx.model === "object" ? ctx.model : {};
  let tokens = 0;
  try {
    const usage = typeof ctx?.getContextUsage === "function" ? ctx.getContextUsage() : undefined;
    if (usage && typeof usage.tokens === "number") tokens = usage.tokens;
    else if (usage && typeof usage.input_tokens === "number") tokens = usage.input_tokens;
  } catch { tokens = 0; }
  const cwd = typeof ctx?.cwd === "string" ? ctx.cwd : "";
  return {
    session_id: sessionId,
    cwd,
    workspace: { current_dir: cwd },
    model: {
      id: typeof model.id === "string" ? model.id : "",
      display_name: typeof model.displayName === "string" ? model.displayName :
        (typeof model.id === "string" && model.id ? model.id : "Pi"),
    },
    context_window: {
      context_window_size: typeof model.contextWindow === "number" ? model.contextWindow : 0,
      current_usage: { input_tokens: tokens },
    },
  };
}

export function executeStatuslineScript(scriptPath, payload, options = {}) {
  const encoded = serializePayload(payload ?? {});
  const timeoutMs = boundedOption(options.timeoutMs, MAX_CHILD_TIMEOUT_MS, MAX_CHILD_TIMEOUT_MS, "statusline timeout");
  const maxOutputBytes = boundedOption(options.maxOutputBytes, MAX_STATUSLINE_OUTPUT_BYTES, MAX_STATUSLINE_OUTPUT_BYTES, "statusline output limit");
  const sessionId = typeof payload?.session_id === "string" ? payload.session_id : "";
  const cwd = options.cwd || dirname(scriptPath);
  return new Promise((resolveResult, reject) => {
    let stdout = "";
    let stderr = "";
    let childOutputBytes = 0;
    let pendingError;
    let terminating = false;
    let settled = false;
    let terminationPromise = Promise.resolve();
    let terminationTimer;
    let closed = false;
    const stdoutDecoder = new StringDecoder("utf8");
    const stderrDecoder = new StringDecoder("utf8");
    const child = spawn(process.execPath, [scriptPath], {
      shell: false,
      cwd,
      env: statuslineChildEnvironment(sessionId),
      detached: process.platform !== "win32",
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });
    const cleanup = () => {
      clearTimeout(timer);
      clearTimeout(terminationTimer);
    };
    const requestTermination = (error) => {
      if (!pendingError) pendingError = error;
      if (terminating) return;
      terminating = true;
      child.stdout.pause();
      child.stderr.pause();
      terminationPromise = terminateProcessTree(child);
      terminationTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        child.stdin.destroy();
        child.stdout.destroy();
        child.stderr.destroy();
        reject(pendingError);
      }, MAX_TERMINATION_WAIT_MS);
    };
    const append = (stream, chunk) => {
      childOutputBytes += chunk.length;
      if (childOutputBytes > maxOutputBytes) {
        requestTermination(new Error("statusline output exceeded limit"));
        return;
      }
      if (stream === "stdout") stdout += stdoutDecoder.write(chunk);
      else stderr += stderrDecoder.write(chunk);
    };
    child.stdout.on("data", (chunk) => append("stdout", chunk));
    child.stderr.on("data", (chunk) => append("stderr", chunk));
    child.once("error", (error) => requestTermination(error));
    child.once("close", async (code, signal) => {
      closed = true;
      if (settled) return;
      stdout += stdoutDecoder.end();
      stderr += stderrDecoder.end();
      await terminationPromise;
      if (settled) return;
      settled = true;
      cleanup();
      if (pendingError) reject(pendingError);
      else resolveResult({ stdout, stderr, code: code ?? -1, signal });
    });
    const timer = setTimeout(() => requestTermination(new Error(`statusline timed out after ${timeoutMs}ms`)), timeoutMs);
    child.stdin.on("error", (error) => {
      if (!closed && error?.code !== "EPIPE" && error?.code !== "ECONNRESET" && error?.code !== "EOF") {
        requestTermination(error);
      }
    });
    child.stdin.end(encoded);
  });
}

function splitFooterLines(text) {
  return String(text || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter((line, index, lines) => {
    return line.length > 0 || index < lines.length - 1;
  }).filter((line, index, lines) => !(index === lines.length - 1 && line === ""));
}

function truncateFooterLine(line, width) {
  if (!Number.isInteger(width) || width < 1 || line.length <= width) return line;
  return line.slice(0, width);
}

const STATUSLINE_MODES = new Set(["full", "compact", "minimal", "none"]);

/** Normalize AgentKit statusline mode; unknown values keep Pi's native footer. */
export function normalizeStatuslineMode(value) {
  if (typeof value !== "string") return "none";
  const mode = value.trim().toLowerCase();
  return STATUSLINE_MODES.has(mode) ? mode : "none";
}

/**
 * Resolve AgentKit statusline mode for Pi footer install.
 * Default is `none`: skip setFooter so Pi keeps its native footer.
 * AgentKit only takes over when the caller passes an explicit non-none mode.
 */
export function resolveAgentKitStatuslineMode(options = {}) {
  if (typeof options.statuslineMode === "string" && options.statuslineMode.trim()) {
    return normalizeStatuslineMode(options.statuslineMode);
  }
  return "none";
}

let footerInstallOwner;

export function watchFooterRegistration(ui) {
  if (!ui || typeof ui.setFooter !== "function") return null;
  if (ui[FOOTER_GUARD]) return ui[FOOTER_GUARD];
  const original = ui.setFooter.bind(ui);
  const state = { occupied: false, owner: undefined };
  ui.setFooter = (factory) => {
    if (factory) {
      if (state.occupied && state.owner && state.owner !== footerInstallOwner) return;
      state.occupied = true;
      if (!state.owner) state.owner = footerInstallOwner || "foreign";
    } else {
      state.occupied = false;
      state.owner = undefined;
    }
    return original(factory);
  };
  Object.defineProperty(ui, FOOTER_GUARD, { value: state, enumerable: false });
  return state;
}

function createStatuslineFooter(ctx, scriptPath, tui, options) {
  let lines = [];
  let inflight = false;
  const refresh = () => {
    if (inflight) return;
    inflight = true;
    executeStatuslineScript(scriptPath, synthesizeClaudeStatuslinePayload(ctx), options)
      .then((result) => {
        lines = result?.code === 0 ? splitFooterLines(result.stdout) : [];
        if (typeof tui?.requestRender === "function") tui.requestRender();
      })
      .catch(() => { lines = []; })
      .finally(() => { inflight = false; });
  };
  refresh();
  return {
    render(width) { return lines.map((line) => truncateFooterLine(line, width)); },
    invalidate() { refresh(); },
    dispose() {},
  };
}

export function installAgentKitStatuslineFooter(ctx, options = {}) {
  if (!ctx || ctx.mode !== "tui") return { installed: false, reason: "not-tui" };
  const mode = resolveAgentKitStatuslineMode({
    ...options,
    cwd: typeof options.cwd === "string" && options.cwd ? options.cwd : ctx.cwd,
  });
  if (mode === "none") return { installed: false, reason: "disabled" };
  const ui = ctx.ui;
  const state = watchFooterRegistration(ui);
  if (!state) return { installed: false, reason: "no-setFooter" };
  if (state.occupied && state.owner !== AGENTKIT_FOOTER_OWNER) {
    return { installed: false, reason: "foreign" };
  }
  let scriptPath = options.scriptPath || "";
  if (!scriptPath && options.root) scriptPath = resolveOwnedStatuslineScript(options.root);
  if (!scriptPath) return { installed: false, reason: "missing-script" };
  if (options.root) {
    try { scriptPath = containedStatuslinePath(options.root, scriptPath); }
    catch { return { installed: false, reason: "unsafe-script" }; }
  }
  footerInstallOwner = AGENTKIT_FOOTER_OWNER;
  try {
    ui.setFooter((tui) => createStatuslineFooter(ctx, scriptPath, tui, options));
  } finally {
    footerInstallOwner = undefined;
  }
  state.owner = AGENTKIT_FOOTER_OWNER;
  return { installed: true };
}

function scheduleStatuslineFooter(ctx, options) {
  if (ctx?.mode !== "tui") return;
  watchFooterRegistration(ctx.ui);
  queueMicrotask(() => {
    try { installAgentKitStatuslineFooter(ctx, options); } catch { /* footer is best-effort */ }
  });
}

const ASK_OR_QUESTION_TOOL_ALIASES = new Set([
  "ask",
  "askuser",
  "askuserquestion",
  "askquestion",
  "askhuman",
  "question",
  "userquestion",
  "questionuser",
]);

export function isAskOrQuestionToolName(name) {
  const compact = String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  return ASK_OR_QUESTION_TOOL_ALIASES.has(compact);
}

export function askUserUIAvailable(ctx) {
  if (!ctx || ctx.hasUI !== true || ctx.mode !== "tui") return false;
  if (!ctx.ui) return true;
  return typeof ctx.ui.select === "function" && typeof ctx.ui.input === "function";
}

export function inspectAskUserPresence(pi) {
  if (pi && pi[ASK_REGISTER_GUARD]) return { exists: true, reason: "exists" };
  if (!pi || typeof pi.getAllTools !== "function") {
    return { exists: true, reason: "no-getAllTools" };
  }
  try {
    const tools = pi.getAllTools();
    if (!Array.isArray(tools)) return { exists: true, reason: "malformed-tools" };
    for (const tool of tools) {
      if (!tool || typeof tool !== "object" || typeof tool.name !== "string" || !tool.name.trim()) {
        return { exists: true, reason: "malformed-tools" };
      }
      if (isAskOrQuestionToolName(tool.name)) {
        return { exists: true, reason: "exists" };
      }
    }
    return { exists: false, reason: "absent" };
  } catch {
    return { exists: true, reason: "inspect-failed" };
  }
}

export function askUserParameterSchema() {
  return {
    type: "object",
    properties: {
      question: {
        type: "string",
        description: "Question to show the user",
      },
      options: {
        type: "array",
        items: { type: "string" },
        description: "Optional choices. When present, the user picks one; otherwise they type a free-text answer.",
      },
      placeholder: {
        type: "string",
        description: "Optional placeholder for free-text input",
      },
    },
    required: ["question"],
  };
}

function normalizeAskOptions(raw) {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) throw new Error("ask_user options must be an array.");
  if (raw.length > MAX_ASK_OPTIONS) throw new Error("ask_user has too many options.");
  const options = [];
  for (const item of raw) {
    let label = "";
    if (typeof item === "string") {
      label = item.trim();
    } else if (item && typeof item === "object" && typeof item.label === "string") {
      label = item.label.trim();
      const description = typeof item.description === "string" ? item.description.trim() : "";
      if (label && description) label = `${label} — ${description}`;
    } else {
      throw new Error("ask_user options must be strings.");
    }
    if (!label) throw new Error("ask_user options must be non-empty.");
    if (byteLength(label) > MAX_ASK_OPTION_BYTES) throw new Error("ask_user option is too long.");
    options.push(label);
  }
  return options;
}

export async function executeAskUser(params, signal, ctx) {
  const question = typeof params?.question === "string" ? params.question.trim() : "";
  if (!question) throw new Error("ask_user requires a question.");
  if (byteLength(question) > MAX_ASK_QUESTION_BYTES) throw new Error("ask_user question is too long.");
  if (!askUserUIAvailable(ctx)) {
    throw new Error("ask_user has no interactive dialog in this session. Ask in chat instead.");
  }
  const options = normalizeAskOptions(params?.options);
  const dialogOpts = signal ? { signal } : undefined;
  if (options.length > 0) {
    if (!ctx.ui || typeof ctx.ui.select !== "function") {
      throw new Error("ask_user select dialog is unavailable.");
    }
    const choice = await ctx.ui.select(question, options, dialogOpts);
    if (choice === undefined || choice === null) {
      throw new Error("User cancelled the question.");
    }
    const text = String(choice);
    return { content: [{ type: "text", text }], details: { kind: "select", choice: text } };
  }
  if (!ctx.ui || typeof ctx.ui.input !== "function") {
    throw new Error("ask_user input dialog is unavailable.");
  }
  const placeholder = typeof params?.placeholder === "string" ? params.placeholder : undefined;
  const answer = await ctx.ui.input(question, placeholder, dialogOpts);
  if (answer === undefined || answer === null) {
    throw new Error("User cancelled the question.");
  }
  const text = String(answer);
  return { content: [{ type: "text", text }], details: { kind: "input", answer: text } };
}

export function registerAskUserIfAbsent(pi, options = {}) {
  const presence = inspectAskUserPresence(pi);
  if (presence.exists) {
    return { registered: false, reason: presence.reason };
  }
  if (!askUserUIAvailable(options)) {
    return { registered: false, reason: "no-ui" };
  }
  if (!pi || typeof pi.registerTool !== "function") {
    return { registered: false, reason: "no-registerTool" };
  }
  const parameters = options.parameters || askUserParameterSchema();
  if (pi && typeof pi === "object") pi[ASK_REGISTER_GUARD] = true;
  try {
    pi.registerTool({
      name: ASK_USER_TOOL_NAME,
      label: "Ask User",
      description: "Ask the user a question with optional choices, or collect a free-text answer.",
      promptSnippet: "Ask the user a question (choices or free text) when an interactive UI is available.",
      parameters,
      async execute(_toolCallId, params, signal, _onUpdate, ctx) {
        return executeAskUser(params, signal, ctx);
      },
    });
  } catch (error) {
    if (pi && typeof pi === "object") delete pi[ASK_REGISTER_GUARD];
    throw error;
  }
  return { registered: true };
}

function scheduleAskUserRegistration(pi, ctx) {
  try {
    const result = registerAskUserIfAbsent(pi, ctx || {});
    if (result.registered || result.reason === "exists" || result.reason === "no-ui") return;
    notifyAskUserRegistration(ctx, `ask_user not registered: ${result.reason}`);
  } catch {
    notifyAskUserRegistration(ctx, "ask_user registration failed");
  }
}

function notifyAskUserRegistration(ctx, message) {
  if (!ctx?.ui || typeof ctx.ui.notify !== "function") return;
  try {
    ctx.ui.notify(message, "warning");
  } catch {
    /* session startup must continue */
  }
}

const MAX_RULE_FILES = 32;
const MAX_RULE_CHARS = 12 * 1024;
const MAX_RULE_INJECTION_CHARS = 40 * 1024;
const OWNED_RULE_STEM = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const MUTATING_RULE_TOOLS = new Set(["edit", "write"]);

function kitNameFromExtensionRoot(root) {
  const dirName = basename(extensionRoot(root));
  if (!dirName.startsWith("agentkit-hooks-")) return "";
  const kit = dirName.slice("agentkit-hooks-".length);
  if (!kit || kit.includes("\0") || kit.includes("/") || kit.includes("\\") || kit.includes("..")) return "";
  return kit;
}

function projectRulesDir(root) {
  const extensionsDir = dirname(extensionRoot(root));
  if (basename(extensionsDir) !== "extensions") return "";
  const piDir = dirname(extensionsDir);
  if (basename(piDir) !== ".pi") return "";
  return join(piDir, "rules");
}

export function isOwnedRuleFileName(kit, fileName) {
  if (typeof kit !== "string" || typeof fileName !== "string" || !kit || fileName.includes("\0")) return false;
  const prefix = `ak-${kit}-`;
  if (!fileName.startsWith(prefix) || !fileName.endsWith(".md")) return false;
  return OWNED_RULE_STEM.test(fileName.slice(prefix.length, -3));
}

function parseRuleFrontmatter(text) {
  const newline = text.startsWith("---\r\n") ? "\r\n" : (text.startsWith("---\n") ? "\n" : "");
  if (!newline) return { paths: [], body: text };
  const close = text.indexOf(`${newline}---`, 4);
  if (close < 0) return { paths: [], body: text };
  const frontmatter = text.slice(4, close);
  const rest = text.slice(close + newline.length + 3).replace(/^\r?\n/, "");
  const paths = [];
  let inPaths = false;
  for (const rawLine of frontmatter.split(/\r?\n/)) {
    const line = rawLine.replace(/\t/g, "  ");
    if (/^paths:\s*$/.test(line)) {
      inPaths = true;
      continue;
    }
    if (inPaths) {
      const item = line.match(/^\s+-\s+(?:["'](.+)["']|(\S+))\s*$/);
      if (item) {
        const value = item[1] || item[2];
        if (value && !value.includes("\0") && paths.length < 32) paths.push(value);
        continue;
      }
      if (/^\s*$/.test(line)) continue;
      inPaths = false;
    }
  }
  return { paths, body: rest || text };
}

function inspectOwnedRuleFile(dir, fileName) {
  const absolute = resolve(dir, fileName);
  if (!isAbsolute(absolute) || (absolute !== dir && !absolute.startsWith(dir + sep))) {
    return { error: "unreadable" };
  }
  let info;
  try { info = lstatSync(absolute); } catch { return { error: "unreadable" }; }
  if (!info.isFile() || info.isSymbolicLink()) return { error: "unreadable" };
  if (info.size > MAX_RULE_CHARS) return { error: "oversized" };
  let text;
  try { text = readFileSync(absolute, "utf8"); } catch { return { error: "unreadable" }; }
  if (byteLength(text) > MAX_RULE_CHARS) return { error: "oversized" };
  const parsed = parseRuleFrontmatter(text);
  return {
    rule: {
      id: fileName.slice(0, -3),
      fileName,
      paths: parsed.paths,
      body: parsed.body,
    },
  };
}

export function scanOwnedProjectRules(rootDir) {
  const empty = { rules: [], failures: [] };
  const kit = kitNameFromExtensionRoot(rootDir);
  if (!kit) return empty;
  const dir = projectRulesDir(rootDir);
  if (!dir) return empty;
  let dirInfo;
  try { dirInfo = lstatSync(dir); } catch { return empty; }
  if (!dirInfo.isDirectory() || dirInfo.isSymbolicLink()) return empty;
  let entries;
  try { entries = readdirSync(dir); } catch { return empty; }
  const rules = [];
  const failures = [];
  for (const name of entries) {
    if (!isOwnedRuleFileName(kit, name)) continue;
    if (rules.length >= MAX_RULE_FILES) {
      failures.push({ fileName: name, reason: "too-many" });
      continue;
    }
    const inspected = inspectOwnedRuleFile(dir, name);
    if (inspected.error) failures.push({ fileName: name, reason: inspected.error });
    else if (inspected.rule) rules.push(inspected.rule);
  }
  return { rules, failures };
}

function globToRegExp(pattern) {
  let source = "^";
  for (let i = 0; i < pattern.length; i += 1) {
    const char = pattern[i];
    if (char === "*" && pattern[i + 1] === "*") {
      if (pattern[i + 2] === "/") {
        source += "(?:.*/)?";
        i += 2;
      } else {
        source += ".*";
        i += 1;
      }
      continue;
    }
    if (char === "*") {
      source += "[^/]*";
      continue;
    }
    if (char === "?") {
      source += "[^/]";
      continue;
    }
    source += char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(`${source}$`);
}

function toolTargetPath(input) {
  if (!input || typeof input !== "object") return "";
  for (const key of ["path", "file_path", "filePath"]) {
    if (typeof input[key] === "string" && input[key] && !input[key].includes("\0")) return input[key];
  }
  return "";
}

function relativizeToolPath(cwd, target) {
  const root = resolve(String(cwd || "."));
  const absolute = isAbsolute(target) ? resolve(target) : resolve(root, target);
  if (absolute === root) return "";
  if (absolute.startsWith(root + sep)) return absolute.slice(root.length + 1).split(sep).join("/");
  return absolute.split(sep).join("/");
}

function ruleMatchesPath(rule, relPath) {
  if (!relPath || !rule.paths.length) return false;
  return rule.paths.some((pattern) => {
    try { return globToRegExp(pattern).test(relPath); } catch { return false; }
  });
}

function formatRuleInjection(rules) {
  const parts = [];
  const included = [];
  let bytes = 0;
  for (const rule of rules) {
    const block = `# ${rule.fileName}\n${rule.body}`.trim();
    const size = byteLength(block);
    if (!block || size > MAX_RULE_CHARS || bytes + size > MAX_RULE_INJECTION_CHARS) continue;
    parts.push(block);
    included.push(rule);
    bytes += size;
  }
  return { content: parts.join("\n\n"), included };
}

export function createAgentKitHookBridge(pi, supplied = {}) {
  const root = extensionRoot(supplied.rootDir || new URL(".", import.meta.url));
  const config = supplied.config === undefined ? loadConfig(root) : validateConfig(supplied.config);
  const timeoutMs = boundedOption(supplied.timeoutMs, MAX_CHILD_TIMEOUT_MS, MAX_CHILD_TIMEOUT_MS, "hook timeout");
  const pipelineTimeoutMs = boundedOption(supplied.pipelineTimeoutMs, MAX_PIPELINE_TIMEOUT_MS, MAX_PIPELINE_TIMEOUT_MS, "pipeline timeout");
  const maxOutputBytes = boundedOption(supplied.maxOutputBytes, MAX_CHILD_OUTPUT_BYTES, MAX_CHILD_OUTPUT_BYTES, "hook output limit");
  let pendingPrompts = [];
  let pendingBytes = 0;
  let pendingLifecycle = [];
  let pendingLifecycleBytes = 0;
  const scannedRules = scanOwnedProjectRules(root);
  const ownedRules = scannedRules.rules;
  const ruleLoadFailed = scannedRules.failures.length > 0;
  const unconditionalRules = ownedRules.filter((rule) => rule.paths.length === 0);
  const scopedRules = ownedRules.filter((rule) => rule.paths.length > 0);
  const injectedRuleIds = new Map();
  const queuedScopedRules = new Map();
  const sessionRuleSet = (store, sessionId) => {
    let value = store.get(sessionId);
    if (!value) {
      value = new Set();
      store.set(sessionId, value);
    }
    return value;
  };
  const resetRuleEpoch = (sessionId) => {
    if (!sessionId) return;
    injectedRuleIds.delete(sessionId);
    queuedScopedRules.delete(sessionId);
  };
  const consumeRuleInjection = (sessionId) => {
    if (!ownedRules.length || !sessionId) return "";
    const injected = sessionRuleSet(injectedRuleIds, sessionId);
    const queued = queuedScopedRules.get(sessionId) || [];
    queuedScopedRules.delete(sessionId);
    const pending = [];
    for (const rule of unconditionalRules) {
      if (!injected.has(rule.id)) pending.push(rule);
    }
    for (const rule of queued) {
      if (!injected.has(rule.id)) pending.push(rule);
    }
    const formatted = formatRuleInjection(pending);
    if (!formatted.content) {
      if (queued.length) queuedScopedRules.set(sessionId, queued);
      return "";
    }
    for (const rule of formatted.included) injected.add(rule.id);
    const omittedScoped = queued.filter((rule) => !formatted.included.some((item) => item.id === rule.id));
    if (omittedScoped.length) queuedScopedRules.set(sessionId, omittedScoped);
    return formatted.content;
  };
  const applyScopedRules = (sessionId, event, ctx) => {
    if (!scopedRules.length) return;
    const toolName = String(event.toolName || "").toLowerCase();
    const target = toolTargetPath(event.input);
    if (!target) return;
    const relPath = relativizeToolPath(ctx.cwd, target);
    const injected = sessionRuleSet(injectedRuleIds, sessionId);
    const matches = scopedRules.filter((rule) => !injected.has(rule.id) && ruleMatchesPath(rule, relPath));
    if (!matches.length) return;
    const queued = queuedScopedRules.get(sessionId) || [];
    for (const rule of matches) {
      if (!queued.some((item) => item.id === rule.id)) queued.push(rule);
    }
    queuedScopedRules.set(sessionId, queued);
    if (!MUTATING_RULE_TOOLS.has(toolName)) return;
    const formatted = formatRuleInjection(matches);
    if (formatted.content) {
      pi.sendMessage({ customType: "agentkit-rules", content: formatted.content, display: false }, { deliverAs: "steer" });
    }
    return {
      block: true,
      reason: `AgentKit rule ${matches[0].fileName} applies to this path; retry after the rule is in context`,
    };
  };
  const optionsFor = (ctx, sessionId, extraSignal) => ({
    root, cwd: ctx.cwd, sessionId, timeoutMs, pipelineTimeoutMs, maxOutputBytes,
    signals: [ctx.signal, extraSignal].filter(Boolean),
  });
  const expirePrompts = () => {
    const cutoff = Date.now() - PROMPT_CONTEXT_TTL_MS;
    while (pendingPrompts.length && pendingPrompts[0].created < cutoff) pendingBytes -= pendingPrompts.shift().bytes;
  };
  const evictLifecycle = (neededBytes) => {
    while (pendingLifecycle.length && (pendingLifecycle.length >= MAX_PENDING_PROMPTS || pendingLifecycleBytes + neededBytes > MAX_PENDING_CONTEXT_BYTES)) {
      pendingLifecycleBytes -= pendingLifecycle.shift().bytes;
    }
  };
  const rememberPrompt = (sessionId, prompt, contexts) => {
    if (!sessionId || !contexts.length || typeof prompt !== "string" || byteLength(prompt) > MAX_PROMPT_BYTES) return;
    const content = contexts.join("\n\n");
    const bytes = byteLength(content);
    if (bytes > MAX_PENDING_CONTEXT_BYTES) return;
    expirePrompts();
    while (pendingPrompts.length && (pendingPrompts.length >= MAX_PENDING_PROMPTS || pendingBytes + bytes > MAX_PENDING_CONTEXT_BYTES)) {
      pendingBytes -= pendingPrompts.shift().bytes;
    }
    pendingPrompts.push({ sessionId, prompt, content, bytes, created: Date.now() });
    pendingBytes += bytes;
  };
  const rememberLifecycle = (sessionId, contexts) => {
    if (!sessionId || !contexts.length) return;
    const content = contexts.join("\n\n");
    const bytes = byteLength(content);
    if (bytes > MAX_PENDING_CONTEXT_BYTES) return;
    evictLifecycle(bytes);
    pendingLifecycle.push({ sessionId, content, bytes });
    pendingLifecycleBytes += bytes;
  };
  const consumePrompt = (sessionId) => {
    expirePrompts();
    // Consume the oldest pending context for this session. Pi may expand slash
    // commands between UserPromptSubmit and before_agent_start, so prompt text
    // is not a stable key.
    const index = pendingPrompts.findIndex((entry) => entry.sessionId === sessionId);
    if (index < 0) return "";
    const [entry] = pendingPrompts.splice(index, 1);
    pendingBytes -= entry.bytes;
    return entry.content;
  };
  const consumeLifecycle = (sessionId) => {
    const parts = [];
    pendingLifecycle = pendingLifecycle.filter((entry) => {
      if (entry.sessionId !== sessionId) return true;
      parts.push(entry.content);
      pendingLifecycleBytes -= entry.bytes;
      return false;
    });
    return parts.join("\n\n");
  };
  const consumeTurnContext = (sessionId) => {
    return [consumeLifecycle(sessionId), consumePrompt(sessionId)].filter(Boolean).join("\n\n");
  };
  const clearSessionState = (sessionId) => {
    pendingPrompts = pendingPrompts.filter((entry) => {
      if (entry.sessionId !== sessionId) return true;
      pendingBytes -= entry.bytes;
      return false;
    });
    pendingLifecycle = pendingLifecycle.filter((entry) => {
      if (entry.sessionId !== sessionId) return true;
      pendingLifecycleBytes -= entry.bytes;
      return false;
    });
  };

  const resetRulesOnCompact = (ctx) => {
    if (!ownedRules.length) return;
    try { resetRuleEpoch(boundedSessionID(ctx.sessionManager.getSessionId())); } catch { /* fail open */ }
  };

  if (config.hooks.PreCompact?.length) {
    pi.on("session_before_compact", async (event, ctx) => {
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      const payload = {
        ...basePayload("PreCompact", ctx, sessionId), runtime: "pi", trigger: event.reason, compact_reason: event.reason, will_retry: Boolean(event.willRetry),
      };
      // Capture hooks never cancel or replace Pi's native compaction.
      await runPipeline(config, "PreCompact", payload, "*", optionsFor(ctx, sessionId, event.signal));
      resetRulesOnCompact(ctx);
    });
  } else if (ownedRules.length) {
    pi.on("session_before_compact", (_event, ctx) => {
      resetRulesOnCompact(ctx);
    });
  }
  if (ownedRules.length) {
    pi.on("session_compact", (_event, ctx) => {
      resetRulesOnCompact(ctx);
    });
  }

  if (config.hooks.PreToolUse?.length || scopedRules.length || ruleLoadFailed) {
    pi.on("tool_call", async (event, ctx) => {
      const toolName = String(event.toolName || "").toLowerCase();
      if (!TOOL_NAMES[toolName]) return;
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch {
        if (config.hooks.PreToolUse?.length) {
          return { block: true, reason: "AgentKit security hooks rejected an invalid Pi session identity" };
        }
        return;
      }
      if (config.hooks.PreToolUse?.length) {
        const payload = { ...basePayload("PreToolUse", ctx, sessionId), tool_name: TOOL_NAMES[toolName], tool_input: event.input, tool_use_id: event.toolCallId };
        const outcome = await runPipeline(config, "PreToolUse", payload, toolName, optionsFor(ctx, sessionId));
        if (outcome.updatedInput) Object.assign(event.input, outcome.updatedInput);
        sendContexts(pi, outcome.contexts);
        if (outcome.block) return { block: true, reason: outcome.reason };
      }
      if (ruleLoadFailed && MUTATING_RULE_TOOLS.has(toolName)) {
        return { block: true, reason: "AgentKit owned rules are unavailable because an owned rule file could not be loaded" };
      }
      return applyScopedRules(sessionId, event, ctx);
    });
  }

  if (config.hooks.PostToolUse?.length) {
    pi.on("tool_result", async (event, ctx) => {
      const toolName = String(event.toolName || "").toLowerCase();
      if (!TOOL_NAMES[toolName]) return;
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      const payload = {
        ...basePayload("PostToolUse", ctx, sessionId), tool_name: TOOL_NAMES[toolName], tool_input: event.input,
        tool_use_id: event.toolCallId, tool_response: { content: event.content, details: event.details, is_error: event.isError },
      };
      const outcome = await runPipeline(config, "PostToolUse", payload, toolName, optionsFor(ctx, sessionId));
      if (outcome.contexts.length) return { content: [...event.content, ...outcome.contexts.map((text) => ({ type: "text", text }))] };
    });
  }

  const statuslineOptions = {
    root,
    scriptPath: typeof supplied.statuslineScriptPath === "string" ? supplied.statuslineScriptPath : "",
    statuslineMode: typeof supplied.statuslineMode === "string" ? supplied.statuslineMode : "",
    timeoutMs,
  };

  if (config.hooks.SessionStart?.length) {
    pi.on("session_start", async (event, ctx) => {
      scheduleAskUserRegistration(pi, ctx);
      scheduleStatuslineFooter(ctx, statuslineOptions);
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      const payload = { ...basePayload("SessionStart", ctx, sessionId), source: sessionStartSource(event?.reason) };
      const outcome = await runPipeline(config, "SessionStart", payload, "*", optionsFor(ctx, sessionId));
      rememberLifecycle(payload.session_id, outcome.contexts);
    });
  } else {
    pi.on("session_start", async (_event, ctx) => {
      scheduleAskUserRegistration(pi, ctx);
      scheduleStatuslineFooter(ctx, statuslineOptions);
    });
  }

  if (config.hooks.Stop?.length) {
    // Idle after retry/compaction is agent_settled, not agent_end.
    pi.on("agent_settled", async (_event, ctx) => {
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      const payload = basePayload("Stop", ctx, sessionId);
      const outcome = await runPipeline(config, "Stop", payload, "*", optionsFor(ctx, sessionId));
      rememberLifecycle(payload.session_id, outcome.contexts);
    });
  }

  if (config.hooks.UserPromptSubmit?.length) {
    pi.on("input", async (event, ctx) => {
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return { action: "continue" }; }
      const payload = { ...basePayload("UserPromptSubmit", ctx, sessionId), prompt: event.text };
      const outcome = await runPipeline(config, "UserPromptSubmit", payload, "*", optionsFor(ctx, sessionId));
      if (outcome.block) {
        if (ctx.hasUI) ctx.ui.notify(outcome.reason, "warning");
        return { action: "handled" };
      }
      rememberPrompt(payload.session_id, event.text, outcome.contexts);
      return { action: "continue" };
    });
  }

  if (config.hooks.UserPromptSubmit?.length || config.hooks.SessionStart?.length || config.hooks.Stop?.length || ownedRules.length) {
    pi.on("before_agent_start", (_event, ctx) => {
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      const hookContent = consumeTurnContext(sessionId);
      const ruleContent = consumeRuleInjection(sessionId);
      const content = [hookContent, ruleContent].filter(Boolean).join("\n\n");
      if (!content) return;
      return {
        message: {
          customType: ruleContent && !hookContent ? "agentkit-rules" : "agentkit-hook",
          content,
          display: false,
        },
      };
    });
    pi.on("session_shutdown", (_event, ctx) => {
      let sessionId;
      try { sessionId = boundedSessionID(ctx.sessionManager.getSessionId()); } catch { return; }
      clearSessionState(sessionId);
      resetRuleEpoch(sessionId);
    });
  }
}

export default function agentKitHookExtension(pi) {
  try {
    createAgentKitHookBridge(pi);
  } catch {
    // A malformed or tampered runtime config must not silently remove the
    // security boundary. The project can repair/reload the owned extension.
    pi.on("tool_call", (event) => {
      const toolName = String(event.toolName || "").toLowerCase();
      if (TOOL_NAMES[toolName]) {
        return { block: true, reason: "AgentKit security hooks are unavailable because their emitted configuration was rejected" };
      }
    });
  }
}
