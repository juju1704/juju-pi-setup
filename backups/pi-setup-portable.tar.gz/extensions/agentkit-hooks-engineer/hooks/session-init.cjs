#!/usr/bin/env node
/**
 * SessionStart Hook - Initializes session environment with project detection
 *
 * Fires: Once per session (startup, resume, clear, compact)
 * Purpose: Load config, detect project info, persist to env vars, output context
 *
 * Exit Codes:
 *   0 - Success (non-blocking, allows continuation)
 *
 * Core detection logic extracted to lib/project-detector.cjs for OpenCode plugin reuse.
 */

// Crash wrapper
try {
  const fs = require('fs');
  const path = require('path');
  const os = require('os');
  const {
    loadConfig,
    createSessionStateContext,
    readSessionState,
    writeEnv,
    updateSessionState,
    resolvePlanPath,
    getReportsPath,
    resolveNamingPattern,
    toDisplayPath,
    extractTaskListId,
    isHookEnabled
  } = require('./lib/ck-config-utils.cjs');
  const { LOG_FILE: HOOK_LOG_FILE, createHookTimer, logHook, logHookCrash } = require('./lib/hook-logger.cjs');
  const { loadProjectCheckpoint, refreshStatuslineSnapshot } = require('./lib/session-state-manager.cjs');
  const { createEmptyActivitySnapshot } = require('./lib/statusline-session-cache.cjs');
  const { renderSessionState, safeDisplayValue } = require('./lib/session-state-renderer.cjs');

  // Early exit if hook disabled in config
  if (!isHookEnabled('session-init')) {
    process.exit(0);
  }

  // Import shared project detection logic
  const {
    detectProjectType,
    detectPackageManager,
    detectFramework,
    getGitBranch,
    getGitRoot,
    getCodingLevelStyleName,
    getCodingLevelGuidelines,
    buildContextOutput
  } = require('./lib/project-detector.cjs');

/**
 * One-time cleanup for orphaned .shadowed/ directories from the disabled skill-dedup hook.
 * The hook is disabled, but existing orphaned skills still need recovery on startup.
 */
function cleanupOrphanedShadowedSkills() {
  const shadowedDir = path.join(process.cwd(), '.claude', 'skills', '.shadowed');
  if (!fs.existsSync(shadowedDir)) return { restored: [], skipped: [], kept: [] };

  const skillsDir = path.join(process.cwd(), '.claude', 'skills');
  const restored = [];
  const skipped = [];
  const kept = [];

  try {
    const entries = fs.readdirSync(shadowedDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const src = path.join(shadowedDir, entry.name);
      const dest = path.join(skillsDir, entry.name);

      try {
        if (!fs.existsSync(dest)) {
          fs.renameSync(src, dest);
          restored.push(entry.name);
          continue;
        }

        const orphanedSkill = path.join(src, 'SKILL.md');
        const localSkill = path.join(dest, 'SKILL.md');
        if (fs.existsSync(orphanedSkill) && fs.existsSync(localSkill)) {
          const orphanedContent = fs.readFileSync(orphanedSkill, 'utf8');
          const localContent = fs.readFileSync(localSkill, 'utf8');
          if (orphanedContent === localContent) {
            fs.rmSync(src, { recursive: true, force: true });
            skipped.push(entry.name);
          } else {
            kept.push(entry.name);
          }
        } else {
          fs.rmSync(src, { recursive: true, force: true });
          skipped.push(entry.name);
        }
      } catch (error) {
        process.stderr.write(`[session-init] Failed to process "${entry.name}": ${error.message}\n`);
      }
    }

    const manifestFile = path.join(shadowedDir, '.dedup-manifest.json');
    if (fs.existsSync(manifestFile)) fs.unlinkSync(manifestFile);
    if (fs.existsSync(shadowedDir) && fs.readdirSync(shadowedDir).length === 0) {
      fs.rmdirSync(shadowedDir);
    }

    return { restored, skipped, kept };
  } catch (error) {
    process.stderr.write(`[session-init] Shadowed cleanup error: ${error.message}\n`);
    return { restored, skipped, kept };
  }
}

/**
 * Detect if this session is running inside an Agent Team.
 * Scans ~/.claude/teams/ for active team configs and checks membership.
 * Note: Returns first team found — Claude Code supports one team per session.
 * Note: Team lifecycle (creation/cleanup) is managed by Claude Code, not this hook.
 * @returns {{ teamName: string, memberCount: number } | null}
 */
function detectAgentTeam() {
  try {
    const teamsDir = path.join(os.homedir(), '.claude', 'teams');
    if (!fs.existsSync(teamsDir)) return null;

    const teams = fs.readdirSync(teamsDir, { withFileTypes: true });
    for (const entry of teams) {
      if (!entry.isDirectory()) continue;
      const configPath = path.join(teamsDir, entry.name, 'config.json');
      if (!fs.existsSync(configPath)) continue;
      try {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (config.members && config.members.length > 0) {
          return { teamName: entry.name, memberCount: config.members.length };
        }
      } catch { /* skip malformed configs */ }
    }
    return null;
  } catch {
    return null;
  }
}

function shouldWarmStatuslineCache(source, snapshot) {
  if (!['startup', 'resume', 'compact'].includes(source)) return false;
  return !snapshot || snapshot.warmed !== true;
}

function pathsReferToSameLocation(left, right) {
  if (!left || !right) return false;
  const normalize = value => {
    const resolved = path.resolve(value);
    return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
  };
  return normalize(left) === normalize(right);
}

// ═══════════════════════════════════════════════════════════════════════════
// STORAGE GC — daily-rate-limited sweep of Claude/Codex session-file bloat.
// Fires on every SessionStart source (hooks.json matches "*"). The sweep
// itself lives in kits/core/scripts/lib/storage-gc.cjs; this hook only owns
// the once-per-calendar-day rate limit (an atomic O_EXCL lockfile claim, not
// a check-then-write stamp, so 20 concurrent SessionStart hooks race safely
// down to exactly one winner) and resolving the shared library's on-disk
// location once a kit is installed/emitted.
// ═══════════════════════════════════════════════════════════════════════════

function formatCalendarDateToken(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

/**
 * Remove any storage-gc-*.lock file that is not today's, so the state
 * directory never accumulates one lockfile per day forever. Best-effort: a
 * lockfile another process is mid-claiming today is never a stale prior-day
 * name, so a concurrent unlink race here cannot affect today's claim.
 */
function sweepPriorDayStorageGcLockfiles(stateDir, todayToken) {
  let entries;
  try {
    entries = fs.readdirSync(stateDir);
  } catch (_) {
    return;
  }
  for (const name of entries) {
    const match = /^storage-gc-(\d{8})\.lock$/.exec(name);
    if (!match || match[1] === todayToken) continue;
    try { fs.unlinkSync(path.join(stateDir, name)); } catch (_) { /* best-effort */ }
  }
}

/**
 * Atomically claim today's storage-gc run via an O_EXCL lockfile open.
 * Returns the claimed lock path on the winning claim, or null on EEXIST (a
 * prior session already claimed today) or any other failure (fails open —
 * storage-gc is best-effort housekeeping, never a blocking dependency).
 */
function claimDailyStorageGcLock(agentkitHome) {
  const stateDir = path.join(agentkitHome, 'state');
  try {
    fs.mkdirSync(stateDir, { recursive: true });
  } catch (_) {
    return null;
  }

  const todayToken = formatCalendarDateToken(new Date());
  sweepPriorDayStorageGcLockfiles(stateDir, todayToken);

  const lockPath = path.join(stateDir, `storage-gc-${todayToken}.lock`);
  let fd;
  try {
    fd = fs.openSync(lockPath, 'wx');
  } catch (_) {
    // EEXIST (already claimed today) or any other open failure — no-op silently.
    return null;
  }
  try {
    fs.writeSync(fd, `${process.pid}\n`);
  } catch (_) {
    // The claim is the exclusive file creation itself; a failed pid write
    // (diagnostic only) does not invalidate an already-won claim.
  } finally {
    try { fs.closeSync(fd); } catch (_) {}
  }
  return lockPath;
}

/**
 * Locate the shared storage-gc.cjs library relative to this hook's own
 * installed location. Checked in order of most to least likely destination
 * across install modes; the raw monorepo source tree (kits/engineer/hooks ->
 * kits/core/scripts/lib) is intentionally NOT one of these, since that
 * relative shape never survives kit emission into an end-user install.
 * Log-and-skip (never throw) if none resolve — see runStorageGc().
 */
function resolveStorageGcModule() {
  const candidates = [
    // Native/simplified-compose layout: scripts/ emitted as a sibling of
    // hooks/ under the runtime root (matches tools/test-kit-hooks.mjs).
    path.join(__dirname, '..', 'scripts', 'lib', 'storage-gc.cjs'),
    // Plugin-mode sidecar layout: scripts/ exports land under
    // <kitOutDir>/.agentkit/scripts/ alongside hooks/ (see
    // apps/cli/internal/adapters/claude-code/sidecar.go).
    path.join(__dirname, '..', '.agentkit', 'scripts', 'lib', 'storage-gc.cjs')
  ];
  // Distinguish "file not present in any candidate" (deploy-shape gap) from
  // "file is present but require threw" (real code bug at load time).
  // Collapsing both into a single "not found" log misroutes debugging to
  // the deploy-shape path when the actual failure is a syntax error.
  const loadErrors = [];
  for (const candidate of candidates) {
    if (!fs.existsSync(candidate)) continue;
    try {
      return { module: require(candidate), path: candidate };
    } catch (error) {
      loadErrors.push({ candidate, message: error && error.message });
    }
  }
  return { module: null, loadErrors };
}

/**
 * Run the daily storage-gc sweep if (and only if) this invocation wins the
 * O_EXCL claim for today. Never throws — every failure mode degrades to a
 * structured log-and-skip so a missing library, unreadable state dir, or
 * sweep error never blocks or crashes SessionStart.
 */
function runStorageGc(environment) {
  const home = environment.HOME || environment.USERPROFILE || os.homedir();
  const agentkitHome = environment.AGENTKIT_HOME || path.join(home, '.agentkit');

  // Dry-run must NOT consume today's O_EXCL claim. If it did, a single
  // diagnostic run would silently disable real sweeps for the next 23h
  // (the winning claim file blocks every subsequent SessionStart today).
  const dryRunRequested = environment.AGENTKIT_STORAGE_GC_DRY_RUN === '1';
  if (!dryRunRequested) {
    const claimedLockPath = claimDailyStorageGcLock(agentkitHome);
    if (!claimedLockPath) return;
  }

  const resolved = resolveStorageGcModule();
  if (!resolved.module) {
    if (resolved.loadErrors.length > 0) {
      for (const err of resolved.loadErrors) {
        logHook('storage-gc', {
          event: 'SessionStart',
          status: 'error',
          note: `storage-gc load failed at ${err.candidate}: ${err.message}`
        });
      }
    } else {
      logHook('storage-gc', {
        event: 'SessionStart',
        status: 'skip',
        note: 'storage-gc module not found at any known kit-relative location'
      });
    }
    return;
  }
  const storageGc = resolved.module;

  try {
    const report = storageGc.sweep({ environment });
    for (const result of report.results) {
      if (result.missing) continue;
      if (result.unknownLayout) {
        logHook('storage-gc', {
          event: 'SessionStart',
          status: 'skip',
          target: result.label,
          note: `unknown layout at ${result.path}, skipping`
        });
        continue;
      }
      logHook('storage-gc', {
        event: 'SessionStart',
        status: 'ok',
        target: result.label,
        note: `storage-gc: swept ${result.deleted.length} files older than ${report.maxAgeDays}d in ${result.label}`
      });
    }
  } catch (error) {
    logHookCrash('storage-gc', error, { event: 'SessionStart' });
  }
}

/**
 * Main hook execution
 */
async function main() {
  const timer = createHookTimer('session-init', { event: 'SessionStart' });
  try {
    const shadowedCleanup = cleanupOrphanedShadowedSkills();
    const stdin = fs.readFileSync(0, 'utf-8').trim();
    const data = stdin ? JSON.parse(stdin) : {};
    const envFile = process.env.CLAUDE_ENV_FILE;
    const source = data.source || 'unknown';
    const sessionId = data.session_id || null;

    // Fires on every SessionStart source (startup/resume/clear/compact — the
    // hooks.json matcher is "*"). Internally rate-limited to once per
    // calendar day via an O_EXCL lockfile claim; never blocks or crashes
    // this hook on failure.
    try {
      runStorageGc(process.env);
    } catch (_) {
      // storage-gc is best-effort housekeeping — never let it fail SessionStart.
    }
    const sessionContext = createSessionStateContext({
      sessionId,
      cwd: data.cwd || process.cwd(),
      bindSession: true
    });
    const existingSession = sessionContext ? readSessionState(sessionContext) : null;

    const config = loadConfig();
    const sessionStateEnabled = config.hooks?.['session-state'] !== false;

    const detections = {
      type: detectProjectType(config.project?.type),
      pm: detectPackageManager(config.project?.packageManager),
      framework: detectFramework(config.project?.framework)
    };

    // Resolve plan - now returns { path, resolvedBy }
    let resolved = resolvePlanPath(sessionContext, config);

    if (sessionContext) {
      updateSessionState(sessionContext, prev => ({
        ...prev,
        activePlan: prev.activePlan || (resolved.resolvedBy === 'session' ? resolved.path : null),
        suggestedPlan: resolved.resolvedBy === 'branch' ? resolved.path : null,
        timestamp: Date.now(),
        source,
        statusline: prev.statusline || createEmptyActivitySnapshot()
      }));
      resolved = resolvePlanPath(sessionContext, config);
    }

    if (sessionStateEnabled && sessionContext && shouldWarmStatuslineCache(source, existingSession?.statusline)) {
      await refreshStatuslineSnapshot(sessionContext, data);
    }

    // Reports path only uses active plans, not suggested ones
    const reportsPath = getReportsPath(resolved.path, resolved.resolvedBy, config.plan, config.paths);

    // Extract task list ID for Claude Code Tasks coordination (shared helper)
    const taskListId = extractTaskListId(resolved);

    // Keep startup metadata cheap. Expensive enrichment is intentionally deferred.
    const staticEnv = {
      nodeVersion: process.version,
      osPlatform: process.platform,
      gitBranch: getGitBranch(),
      gitRoot: getGitRoot(),
      user: process.env.USERNAME || process.env.USER || process.env.LOGNAME || os.userInfo().username,
      locale: process.env.LANG || '',
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      claudeSettingsDir: path.resolve(__dirname, '..')
    };

    // Use CWD as the base for subdirectory-aware absolute paths.
    // Git root is kept in staticEnv for reference, but CWD determines where files are created
    const baseDir = sessionContext?.sessionLaunchRoot || process.cwd();

    // Compute resolved naming pattern (date + issue resolved, {slug} kept as placeholder)
    const namePattern = resolveNamingPattern(config.plan, staticEnv.gitBranch);

    if (envFile) {
      // Session & plan config
      writeEnv(envFile, 'CK_SESSION_ID', sessionId || '');
      writeEnv(envFile, 'CK_PLAN_NAMING_FORMAT', config.plan.namingFormat);
      writeEnv(envFile, 'CK_PLAN_DATE_FORMAT', config.plan.dateFormat);
      writeEnv(envFile, 'CK_PLAN_ISSUE_PREFIX', config.plan.issuePrefix || '');
      writeEnv(envFile, 'CK_PLAN_REPORTS_DIR', config.plan.reportsDir);

      // NEW: Resolved naming pattern for DRY file naming in agents
      // Example: "251212-1830-GH-88-{slug}" or "251212-1830-{slug}"
      // Agents use: `{agent-type}-$CK_NAME_PATTERN.md` and substitute {slug}
      writeEnv(envFile, 'CK_NAME_PATTERN', namePattern);

      // Plan resolution
      writeEnv(envFile, 'CK_ACTIVE_PLAN', resolved.resolvedBy === 'session' ? resolved.path : '');
      writeEnv(envFile, 'CK_SUGGESTED_PLAN', resolved.resolvedBy === 'branch' ? resolved.path : '');

      // Claude Code Tasks integration - enables multi-session/subagent coordination
      // Task list ID = plan directory name (shared across all sessions working on same plan)
      if (taskListId) {
        writeEnv(envFile, 'CLAUDE_CODE_TASK_LIST_ID', taskListId);
      }

      // Use absolute paths based on CWD for subdirectory workflow support.
      // Rendered with forward slashes: a shell interpolates these, and a
      // backslash path loses its separators the moment it is used unquoted.
      writeEnv(envFile, 'CK_GIT_ROOT', staticEnv.gitRoot || '');
      // Resolve each configured path against baseDir only when it is relative.
      // An absolute override (ak init --docs-dir/--plans-dir persists one into
      // the project preference file) must be used verbatim: path.join concatenates
      // rather than resolves, so joining baseDir onto an absolute value yields a
      // bogus /<baseDir>/Users/x/docs location. Mirrors the guards the read path
      // already uses in kits/core/hooks/lib/ck-config-utils.cjs.
      const resolveUnderBase = (p) => (path.isAbsolute(p) ? p : path.join(baseDir, p));
      writeEnv(envFile, 'CK_REPORTS_PATH', toDisplayPath(resolveUnderBase(reportsPath)));
      writeEnv(envFile, 'CK_DOCS_PATH', toDisplayPath(resolveUnderBase(config.paths.docs)));
      writeEnv(envFile, 'CK_PLANS_PATH', toDisplayPath(resolveUnderBase(config.paths.plans)));
      writeEnv(envFile, 'CK_PROJECT_ROOT', toDisplayPath(baseDir));

      // Project detection
      writeEnv(envFile, 'CK_PROJECT_TYPE', detections.type || '');
      writeEnv(envFile, 'CK_PACKAGE_MANAGER', detections.pm || '');
      writeEnv(envFile, 'CK_FRAMEWORK', detections.framework || '');

      // NEW: Static environment info (so other hooks don't need to recompute)
      writeEnv(envFile, 'CK_NODE_VERSION', staticEnv.nodeVersion);
      writeEnv(envFile, 'CK_OS_PLATFORM', staticEnv.osPlatform);
      writeEnv(envFile, 'CK_GIT_BRANCH', staticEnv.gitBranch || '');
      writeEnv(envFile, 'CK_USER', staticEnv.user);
      writeEnv(envFile, 'CK_LOCALE', staticEnv.locale);
      writeEnv(envFile, 'CK_TIMEZONE', staticEnv.timezone);
      writeEnv(envFile, 'CK_CLAUDE_SETTINGS_DIR', staticEnv.claudeSettingsDir);

      // Locale config
      if (config.locale?.thinkingLanguage) {
        writeEnv(envFile, 'CK_THINKING_LANGUAGE', config.locale.thinkingLanguage);
      }
      if (config.locale?.responseLanguage) {
        writeEnv(envFile, 'CK_RESPONSE_LANGUAGE', config.locale.responseLanguage);
      }

      // Plan validation config (for /ak:plan validate, /ak:plan --hard, /ak:plan --parallel)
      const validation = config.plan?.validation || {};
      writeEnv(envFile, 'CK_VALIDATION_MODE', validation.mode || 'prompt');
      writeEnv(envFile, 'CK_VALIDATION_MIN_QUESTIONS', validation.minQuestions || 3);
      writeEnv(envFile, 'CK_VALIDATION_MAX_QUESTIONS', validation.maxQuestions || 8);
      writeEnv(envFile, 'CK_VALIDATION_FOCUS_AREAS', (validation.focusAreas || ['assumptions', 'risks', 'tradeoffs', 'architecture']).join(','));

      // Coding level config (for output style selection)
      const codingLevel = config.codingLevel ?? 5;
      writeEnv(envFile, 'CK_CODING_LEVEL', codingLevel);
      writeEnv(envFile, 'CK_CODING_LEVEL_STYLE', getCodingLevelStyleName(codingLevel));

    }

    // Agent Teams detection — detect once, used for env vars and console output
    const teamInfo = detectAgentTeam();
    if (envFile && teamInfo) {
      writeEnv(envFile, 'CK_AGENT_TEAM', teamInfo.teamName);
      writeEnv(envFile, 'CK_AGENT_TEAM_MEMBERS', teamInfo.memberCount);
    }

    const displaySource = ['startup', 'resume', 'clear', 'compact'].includes(source) ? source : 'unknown';
    console.log(`Session ${displaySource}. ${safeDisplayValue(buildContextOutput(config, detections, resolved, staticEnv.gitRoot), 4096)}`);

    const hasCleanup =
      shadowedCleanup.restored.length > 0 ||
      shadowedCleanup.skipped.length > 0 ||
      shadowedCleanup.kept.length > 0;
    if (hasCleanup) {
      console.log(`\n[!] SKILL-DEDUP CLEANUP:`);
      console.log(`Recovered orphaned .shadowed/ directory from disabled skill-dedup hook.`);
      if (shadowedCleanup.restored.length > 0) {
        console.log(`Restored ${shadowedCleanup.restored.length} skill(s): ${shadowedCleanup.restored.join(', ')}`);
      }
      if (shadowedCleanup.skipped.length > 0) {
        console.log(`Removed ${shadowedCleanup.skipped.length} duplicate(s): ${shadowedCleanup.skipped.join(', ')}`);
      }
      if (shadowedCleanup.kept.length > 0) {
        console.log(`[!] Kept ${shadowedCleanup.kept.length} skill(s) for manual review (content differs): ${shadowedCleanup.kept.join(', ')}`);
        console.log(`    Review .claude/skills/.shadowed/ and merge changes manually.`);
      }
    }

    if (sessionStateEnabled && (source === 'startup' || source === 'compact')) {
      const recoveryState = source === 'compact'
        ? readSessionState(sessionContext)
        : loadProjectCheckpoint(sessionContext);
      const renderedState = renderSessionState({
        ...recoveryState,
        agents: source === 'compact' ? recoveryState?.statusline?.agents : undefined,
        todos: source === 'compact' ? recoveryState?.statusline?.todos : recoveryState?.todos
      }, source);
      if (renderedState) {
        console.log(`\n${renderedState}\n`);
        console.log(source === 'compact'
          ? 'Context was compacted. Re-read the active plan and todo list before continuing.'
          : 'Review the previous-session status data, then continue or start fresh.');
      }
    }

    // Agent Teams: Show team context if running inside a team (uses cached result)
    if (teamInfo) {
      console.log(`[i] Agent Team detected: "${teamInfo.teamName}" (${teamInfo.memberCount} members)`);
      console.log(`    Team config: ~/.claude/teams/${teamInfo.teamName}/config.json`);
      console.log(`    Use /ak:team skill for orchestration templates.`);
    }

    // Show the git root when running from a supported subdirectory.
    if (staticEnv.gitRoot && !pathsReferToSameLocation(staticEnv.gitRoot, process.cwd())) {
      console.log(`📁 Subdirectory mode: Plans/docs will be created in current directory`);
      console.log(`   Git root: ${safeDisplayValue(staticEnv.gitRoot)}`);
    }

    // Auto-compact can bypass AskUserQuestion approval gates.
    // When context is compacted mid-workflow, the summarization may lose "pending approval" state.
    // This warning reminds Claude to verify if user approval was pending before proceeding.
    // Upstream bug: Claude Code CLI should preserve pending interactive state during compaction.
    if (source === 'compact') {
      console.log(`\n⚠️ CONTEXT COMPACTED - APPROVAL STATE CHECK:`);
      console.log(`If you were waiting for user approval via AskUserQuestion (e.g., Step 4 review gate),`);
      console.log(`you MUST re-confirm with the user before proceeding. Do NOT assume approval was given.`);
      console.log(`Use AskUserQuestion to verify: "Context was compacted. Please confirm approval to continue."`);

      // Compaction can drop the record of background processes started earlier
      // this session (PIDs, ports, worktrees). Surface a reconcile-and-clean
      // reminder here -- SessionStart:compact output reaches the model, whereas
      // PreCompact stdout does not -- so orphaned dev servers do not accumulate.
      console.log(`\n🧹 ORPHAN PROCESS CHECK:`);
      console.log(`Before continuing, reconcile the background processes you started earlier this`);
      console.log(`session (dev servers, watchers, tunnels). Note the still-needed ones (command,`);
      console.log(`PID, port, worktree) and stop the rest so orphaned processes do not pile up and`);
      console.log(`exhaust device memory. See .claude/rules/process-management.md.`);

      // Context recovery. The PreCompact hook (precompact-capture.cjs) records
      // the derivable orientation anchors before compaction; surface them here,
      // where hook output reaches the model, and remind the agent to re-establish
      // the parts a hook cannot derive (issues/PRs, plan phase, done vs pending
      // work, and the reasoning behind in-flight decisions).
      const recovery = readSessionState(sessionContext)?.compactRecovery;
      console.log(`\n🧭 CONTEXT RECOVERY:`);
      // Only the machine-derived Git anchors count here. The active plan comes
      // from the checkpoint pipeline, not from the capture, so it must not mask
      // a capture that derived no location.
      let gitAnchorsShown = false;
      if (recovery) {
        if (recovery.worktree) { console.log(`  Worktree: ${safeDisplayValue(recovery.worktree)}`); gitAnchorsShown = true; }
        if (recovery.mainRoot) { console.log(`  Root project: ${safeDisplayValue(recovery.mainRoot)}`); gitAnchorsShown = true; }
        if (recovery.branch || recovery.head) {
          const location = recovery.branch ? safeDisplayValue(recovery.branch) : 'detached HEAD';
          console.log(`  Branch: ${location}${recovery.head ? ` @ ${safeDisplayValue(recovery.head)}` : ''}${recovery.dirtyCount ? ` (${recovery.dirtyCount} uncommitted)` : ''}`);
          gitAnchorsShown = true;
        }
        if (recovery.activePlan) console.log(`  Active plan: ${safeDisplayValue(recovery.activePlan)}`);
      }
      // A capture that skipped or derived nothing used to fall through to the
      // generic prose below, which reads exactly like a normal compaction. Name
      // the gap instead, so the missing anchors are attributable.
      if (!recovery) {
        console.log(`  Orientation anchors unavailable (precompact-capture persisted nothing for this session; see ${safeDisplayValue(HOOK_LOG_FILE)}).`);
      } else if (recovery.anchorsUnavailable || !gitAnchorsShown) {
        console.log(`  Orientation anchors unavailable (precompact-capture: ${safeDisplayValue(recovery.anchorsUnavailable || 'unknown')}).`);
      }
      console.log(`Re-establish before continuing: the issues/PRs in flight, the active plan and`);
      console.log(`current phase, what is done vs. still pending, any failures and their cause, and`);
      console.log(`why the current approach was chosen. Re-read the active plan and notes first.`);
    }

    // Auto-inject coding level guidelines (if not disabled). Resolve styles from
    // the hook's own install root (claudeSettingsDir = __dirname/..): the runtime
    // root for a native install (~/.claude or <project>/.claude) or the plugin
    // root for plugin delivery. getCodingLevelGuidelines probes the active
    // output-styles/ layout then the legacy/build .agentkit/ sidecar.
    const codingLevel = config.codingLevel ?? -1;
    const guidelines = getCodingLevelGuidelines(codingLevel, staticEnv.claudeSettingsDir);
    if (guidelines) {
      console.log(`\n${guidelines}`);
    }

    if (config.assertions?.length > 0) {
      console.log(`\nUser Assertions:`);
      config.assertions.forEach((assertion, i) => {
        console.log(`  ${i + 1}. ${assertion}`);
      });
    }

    timer.end({ status: 'ok', exit: 0, note: source || 'session-start' });
    process.exit(0);
  } catch (error) {
    console.error(`SessionStart hook error: ${error.message}`);
    logHookCrash('session-init', error, { event: 'SessionStart' });
    process.exit(0);
  }
  }

  main();
} catch (e) {
  try {
    const { logHookCrash } = require('./lib/hook-logger.cjs');
    logHookCrash('session-init', e, { event: 'SessionStart' });
  } catch (_) {}
  process.exit(0); // fail-open
}
