#!/usr/bin/env node
// AgentKit Pi sidecar stub: forwards to the runnable script beside hooks.
require("../../scripts/set-active-plan.cjs");
